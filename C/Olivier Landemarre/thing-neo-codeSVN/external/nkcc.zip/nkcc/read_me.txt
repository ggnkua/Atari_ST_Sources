
   NKCC - NORMALIZED KEY CODE CONVERTER
   =============================================================================

   ENGLISH
   -----------------------------------------------------------------------------
   You meet NKCC the first time? Then read the file DOC\ENGLISH.DOC first
   to get familiar with the library's functions.

   All changes of the NKCC package regarding to previous versions are
   documented in the file DOC\NEWS.TXT.



   DEUTSCH
   -----------------------------------------------------------------------------
   F�r Neueinsteiger: bitte zuerst DOC\GERMAN.DOC lesen, um einen �berblick
   �ber die Library zu erhalten.

   Die �nderungen gegen�ber den vorherigen Versionen sind in DOC\NEWS.TXT
   dokumentiert.


   =============================================================================
   End Of File
