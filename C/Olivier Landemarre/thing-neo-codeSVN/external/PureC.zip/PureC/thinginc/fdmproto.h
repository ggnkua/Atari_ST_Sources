#ifndef _FDMPROTO_H_
#define _FDMPROTO_H_

/*
 * Zur direkten Unterst�tzung von Freedom gibt es 2 M�glichkeiten, bei 
 * beiden wird in dem Speicherbereich, auf den fs_iinpath beim fsel_[ex]input
 * Aufruf deutet, zus�tzlich zum Pfad eine Struktur �bergeben.
 * Die Vorgehensweise ist denkbar einfach: Hat man vorher 128 Bytes f�r den
 * Pfad reservieren m�ssen, sind es jetzt 128+sizeof(Fdm_Str).
 * In diesen Speicher (um globale Lesbarkeit unter MiNT m�ssen Sie sich nicht
 * k�mmern) wird die folgende Struktur kopiert, direkt dahinter der Pfad-
 * String. Der Pfad wird also nur um sizeof(Fdm_Str) nach hinten verschoben.
 * Dannach k�nnen Sie zwei Wege beschreiten:
 *
 * 1. �bergeben Sie einfach einen Zeiger auf diesen Speicherbereich in 
 * fs_iinpath. Durch den Magic am Anfang erkennt Freedom sofort, das der
 * Aufrufer das Protokoll unterst�tzen will. Diese Methode hat den Nachteil,
 * da� Sie sie f�r den unwahrscheinlichen Fall, das Freedom nicht installiert
 * ist ;-), nicht anwenden k�nnen. Sie m�ssen also im Cookiejar nachsehen, ob
 * ein FSEL-Cookie mit Version >= 2.00 vorhanden ist (s. SLECTRIC.H)
 *
 * 2. �bergeben Sie einen Zeiger auf den Pfad hinter der Struktur. Das versteht
 * auch jeder andere Fileselektor, Sie brauchen also nicht im Cookie nachzu-
 * sehen, ob Freedom vielleicht nicht installiert ist. Freedom k�nnte ja nun
 * einfach sizeof(Fdm_Str) vor dem �bergebenen Pointer nachsehen, ob der Magic
 * da zuf�llig steht, g�be es da nicht MiNT mit aktivem Speicherschutz. Deshalb
 * m�ssen Sie bei dieser Methode Freedom noch einen Hinweis geben, da� er 
 * gefahrlos auf den Speicher vor dem Pfad zugreifen darf: Findet Freedom 
 * hinter dem Nullbyte des Pfades die vier Zeichen "?Fdm" (dasselbe Magic wie
 * in der Struktur erwartet wird), dann kuckt es vor dem Pfad nach, ob sich die
 * Struktur dort befindet. Und jetzt (Gnade.. .-)): die Struktur:
 */
typedef struct
{
	long magic;   /* '?Fdm' */
	int id;       /* Beliebige Id */
	int maxsel;   /* Maximale Anzahl von zu selektierenden Files */
	struct
	{
        unsigned fullpaths : 1; /* volle Pfadnamen in der Antwort */
        unsigned doquote   : 1; /* Freedom darf quoten */
        unsigned noname    : 1; /* keinen Appl.-Namen vor Titel */
        unsigned sysmodal  : 1; /* System-Modal �ffnen (�rgs..) */
        unsigned resvd     : 28; /* reserviert (auf 0 setzen) */

	} flags;
	int handle;  /* Enth�lt nach Erfolg das Fensterhandle des 
	                Fileselektors (bzw. 0 bei einem fliegenden 
	                Dialog). Sinn: Das aufrufende Programm kann den 
	                Fileselektor kontrollieren, indem es etwa eine 
	                WIN_CLOSED-Nachricht daf�r an Freedom sendet, oder 
	                das Fenster in sein Window-Cycle mit einbezieht.
	              */
    int server;  /* Enth�lt nach Erfolg die Appl.-Id des 
	                Fileselektor-Servers. An ihn k�nnen Nachrichten
	                bzgl. des Fensters 'handle' gesendet werden.
	              */
	char path[0]; /* jetzt kommt der der Pfad.. */

} Fdm_Str;

/*
 * kehrt fsel_input zur�ck, und in der Struktur steht im 'magic'
 * dann ein '!Fdm', war der Aufruf erfolgreich, anderenfalls wurde
 * der Aufruf an das OS weitergeleitet, und die R�ckgabewerte 
 * (fs_iinpath, fs_iinsel, fs_iexbutton) sind g�ltig!
 * 
 * Bei erfolgreichem Aufruf kann die Applikation sich einer Antwort 
 * in Form einer AES-Nachricht sicher sein. Ob die Applikation weiterl�uft
 * oder in einer Sub-Eventloop auf die Antwort wartet, in der Sie sonst
 * und nur WM_REDRAW und Co. bearbeitet, bleibt ihr �berlassen. Am sch�nsten 
 * w�re nat�rlich, wenn ein Weiterarbeiten erm�glicht wird.
 *
 * Das Format der AES-Antwort-Nachricht ist:
 *
 * FILE_SELECTED: Ein Fileselektor wurde geschlossen:
 * Word 3:   Id des Fileselektors (wie bei fsel_[ex]input angegeben)
 * Word 4/5: Zeiger auf Pfad und Extension zum Zeitpunkt
 *           des Schlie�ens
 * Word 6/7: Zeiger auf die ausgew�hlten Files, oder NULL, falls
 *           der Benutzer Abbruch bet�tigt hat
 *           Die Files sind durch Spaces getrennt, und enthalten
 *           je nach den Angaben beim Aufruf volle Pfade bzw.
 *           auch Quotes ('Chrisker''s Briefbeschwerer')
 */
#ifndef FILE_SELECTED
#define FILE_SELECTED	0x4560
#endif
/*
 * In den dem Empfang dieser Nachricht folgenden 10 Sekunden kann das
 * Programm gefahrlos auf den (MiNT-globalen) Speicher, auf die W�rter
 * 3/4 bzw. 6/7 weisen, zugreifen, und die Daten kopieren. Dannach
 * �bergibt Freedom den Speicher wieder an das GEMDOS (Mfree)!
 *
 *
 * Sollen Nachrichten an den Server gesendet werden, sollte man statt der
 * Standard Screenmgr-Nachrichten WM_TOPPED und WM_CLOSED die folgenden
 * Nachrichten-Nummern verwenden. Bei den normalen Nachrichten passiert 
 * n�mlich uU was anderes, als man erwartet. Etwa wird der Fileselektor 
 * ICFS-Ikonifiziert, wenn gerade eine Umschalttaste festgehalten wird 
 * (WM_CLOSED), oder es wird stattdessen das Objekt unter der Maus bedient,
 * weil in Freedom die Simulation von Hintergrundbedienung (WM_TOPPED) unter
 * SingelTOS aktiviert ist.
 */  
#ifndef WIN_TOPPED
#define WIN_TOPPED		0x7a22
#endif
#ifndef WIN_CLOSED
#define WIN_CLOSED		0x7a23
#endif

#endif /* _FDMPROTO_H_ */
