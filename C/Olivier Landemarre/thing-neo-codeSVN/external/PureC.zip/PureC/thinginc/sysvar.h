/*
	SYSVAR.H  (part of TOS.LIB for Pure C)
	TOS system variables (access only in supervisor mode!)

	04/10/2004 written by Philipp Donze (PhilippDonze@gmx.ch)
	 Based on my old SYSVARS.H which is based on Atari Profibuch
*/

#ifndef _SYSVAR_H_
# define _SYSVAR_H_

#define	proc_lives	(long *)0x0380
#define	proc_dregs	(long *)0x0384
#define	proc_aregs	(long *)0x03A4
#define	proc_enum	(long *)0x03C4
#define	proc_usp	(long *)0x03C8
#define	proc_stk	(long *)0x03CC
#define	etv_timer	(long *)0x0400
#define	etv_critic	(long *)0x0404
#define	etv_term	(long *)0x0408
#define	etv_xtra	(long *)0x040C
#define	memvalid	(long *)0x0420		/*	Magic-Value: $752019F3	*/
#define	memcntrl	(char *)0x0424
#define	resvalid	(long *)0x0426		/*	Magic-Value: $31415926	*/
#define	resvector	(long *)0x042A
#define	phystop		(long *)0x042E
#define	_membot		(long *)0x0432
#define	_memtop		(long *)0x0436
#define	memval2		(long *)0x043A		/*	Magic-Value: $237698AA	*/
#define	flock		(int *)0x043E
#define	seekrate	(int *)0x0440
#define	_timr_ms	(int *)0x0442
#define	_fverify	(int *)0x0444
#define	_bootdev	(int *)0x0446
#define	palmode		(int *)0x0448
#define	defshiftmd	(char *)0x044A
#define	sshiftmd	(char *)0x044C
#define	_v_bas_ad	(long *)0x044E
#define	vblsem		(int *)0x0452
#define	nvbls		(int *)0x0454
#define	_vblqueue	(long *)0x0456
#define	colorptr	(long *)0x045A
#define	screenpt	(long *)0x045E
#define	_vbclock	(long *)0x0462
#define	_frclock	(long *)0x0466
#define	hdv_init	(long *)0x046A
#define	swv_vec		(long *)0x046E
#define	hdv_bpb		(long *)0x0472
#define	hdv_rw		(long *)0x0476
#define	hdv_boot	(long *)0x047A
#define	hdv_mediach	(long *)0x047E
#define	_cmdload	(int *)0x0482
#define	conterm		(char *)0x0484
#define	trp14ret	(long *)0x0486			/*	undef	*/
#define	criticret	(long *)0x048A			/*	undef	*/
#define	themd		(long *)0x048E			/*	zeigt auf struct MD	*/
#define	_____md		(long *)0x049E			/*	undef	*/
#define	savptr		(long *)0x04A2
#define	_nflops		(int *)0x04A6
#define	con_state	(long *)0x04A8
#define	sav_row		(int *)0x04AC
#define	sav_context	(long *)0x04AE
#define	_bufl		(long *)0x04B2
#define	_hz_200		(long *)0x04BA
#define	the_env		(long *)0x04BE
#define	_drvbits	(long *)0x04C2
#define	_dskbufp	(long *)0x04C6
#define	_autopath	(long *)0x04CA
#define	_vbl_list	(long *)0x04CE
#define	prt_cnt		(int *)0x04EE
#define	_prtabt		(int *)0x04F0
#define	_sysbase	(long *)0x04F2
#define	_shell_p	(long *)0x04F6
#define	end_os		(long *)0x04FA
#define	exec_os		(long *)0x04FE
#define	scr_dump	(long *)0x0502
#define	prv_lsto	(long *)0x0506
#define	prv_lst		(long *)0x050A
#define	prv_auxo	(long *)0x050E
#define	prv_aux		(long *)0x0512
#define	pun_ptr		(long *)0x0516
#define	memval3		(long *)0x051A			/*	Magic-value: $5555AAAA	*/
#define	xconstat	(long *)0x051E
#define	xconin		(long *)0x053E
#define	xcostat		(long *)0x055E
#define	xconout		(long *)0x057E
#define	_longframe	(int *)0x059E
#define	_p_cookies	(long *)0x05A0
#define	ramtop		(long *)0x05A4
#define	ramvalid	(long *)0x05A8			/* Magic-value: $1357BD13	*/
#define	bell_hook	(long *)0x05AC
#define	kcl_hook	(long *)0x05B0


#endif	/*	_SYSVAR_H_	*/
