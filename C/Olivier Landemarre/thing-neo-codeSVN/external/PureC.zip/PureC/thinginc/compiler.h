/* compiler.h for Pure C */

#ifndef __COMPILER_H__
#define __COMPILER_H__

#ifdef __PUREC__

#define __CDECL cdecl
#define __BEGIN_DECLS
#define __END_DECLS
#define inline


#endif /* __PURE_C__ */

#define __EXTERN
#define __PROTO(x) x



/* macros for POSIX support */
#ifndef __hpux
#define _UID_T unsigned short
#define _GID_T unsigned short
#define _PID_T int
#define _POSIX_VERSION 1
#endif

#endif /* __COMPILER_H__ */
