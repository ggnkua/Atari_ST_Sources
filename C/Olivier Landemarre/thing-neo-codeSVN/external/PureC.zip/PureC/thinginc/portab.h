#if  !defined( __PORTAB__ )
#define __PORTAB__

#define TRUE		1
#define FALSE		0
#define YES			1
#define NO			0
#define ON			1
#define OFF			0
#define FAILURE	(-1)
#define SUCCESS	(0)

#define FOREVER	for(;;)

#define CDECL cdecl

#define CONST		const
#define BOOLEAN	int
#define REG			register
#define EXTERN		extern
#define AUTO		auto
#define LOCAL		static
#define MLOCAL		static
#define GLOBAL
#define VOID		void

typedef char				BYTE;			/*  8 Bit */
typedef unsigned char	UBYTE;		/*  8 Bit */
typedef char				CHAR;			/*  8 Bit */
typedef unsigned char	UCHAR;		/*  8 Bit */
typedef short				WORD;			/* 16 Bit */
typedef unsigned short	UWORD;		/* 16 Bit */
typedef short					INT;			/* 16 Bit */
typedef unsigned short		UINT;			/* 16 Bit */
typedef long				LONG;			/* 32 Bit */
typedef unsigned long	ULONG;		/* 32 Bit */
typedef float				FLOAT;		/* 32 Bit */
typedef long double				REAL;			/* 80 Bit */
typedef long double		LREAL;		/* 80 Bit */

typedef short INT16;


typedef struct
{
	UBYTE		r, g, b;
} RGB24;


#define minof( a, b )		( (a) < (b) ? (a) : (b) )
#define maxof( a, b )		( (a) > (b) ? (a) : (b) )
#define clamp( v, l, h )	( (v) < (l) ? (l) : (v) > (h) ? (h) : (v) )

#define swap( a, b, temp )	( (temp) = (a), (a) = (b), (b) = (temp) )


#ifdef __PUREC__
#if sizeof(double)==12
#define NO_COPRO(a) /* a */
#else
#define NO_COPRO(a) a
typedef short BIDON;
#endif
#else
#define NO_COPRO(a) a
typedef short BIDON[2];
#endif

#endif
