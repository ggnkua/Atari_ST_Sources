	/* 2-9 not used */
/* generic error codes for all codecs */
#define	EP_Fopen			10	/* fopen failed, image file not found */
#define	EP_Fread			11	/* fread failed, size in/out didn't match, or negative error code */
#define	EP_Fwrite			12	/* fwrite failed, size in/out didn't match, or negative error code */
#define	EP_Fclose			13	/* fclose failed */
#define	EP_Fcreate			14	/* fcreate failed */
#define	EP_Fseek			15	/* fseek failed, truncated file? */
#define EP_Malloc			16	/* malloc failed */
#define EP_Mfree			17	/* mfree failed */
	/*18 reserved */
	/*19 reserved */
/* image decoding */
#define EP_DecompType		20	/* header -> invalid decompression type */
#define	EP_DecompError		21	/* error during decompression phase */
#define EP_ResolutionType	22	/* header -> invalid mode code, example: neo image with med or high rez mode code */
#define EP_ImageType		23  /* header -> invalid image type */
#define	EP_PixelDepth		24	/* header -> invalid pixel depth */
#define	EP_ColorMapDepth	25	/* header -> invalid color map depth */
#define	EP_ColorMapType		26	/* header -> invalid color map type */



/*
function plugin_err_to_txt$(err_code)
  ' maybe format as alert strings, etc.
  select err_code
  case ep_fopen
    msg$="fopen failed, file not found"
  case ep_fread
    msg$="fread failed, short read?"
  case ep_fclose
    msg$="fwrite failed, short write, disk full?"
  default		!end up here if not found
    msg$="an unknown error"
  endselect
  return msg$
endfunc
*/
