long _stksize = 0L;	/* "0" means keep minimum amount: see crtinit.c */
