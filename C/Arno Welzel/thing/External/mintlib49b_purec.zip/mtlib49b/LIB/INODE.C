#include <types.h>

ino_t __inode = 32; /* used in readdir, _do_stat, fstat */

