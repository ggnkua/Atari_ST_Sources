/*
 * pipe: create a pipe
 * works only under MiNT
 */

#include <osbind.h>
#include <errno.h>
#include <mintbind.h>
#include <unistd.h>
#include "lib.h"

int
pipe(fd)
	int *fd;
{
	short mint_handle[2];
	long r;

	r = Fpipe(mint_handle);
	if (r < 0) {
		errno = (int) -r;
		return -1;
	}
	fd[0] = mint_handle[0];
	fd[1] = mint_handle[1];
	/* fix the case `isatty() called before and not closed thru close()' */
	if (__OPEN_INDEX(fd[0]) < __NHANDLES)
		__open_stat[__OPEN_INDEX(fd[0])].status = FH_UNKNOWN;
	if (__OPEN_INDEX(fd[1]) < __NHANDLES)
		__open_stat[__OPEN_INDEX(fd[1])].status = FH_UNKNOWN;
	return 0;
}
