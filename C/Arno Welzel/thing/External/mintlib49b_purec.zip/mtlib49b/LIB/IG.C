/* dummy ident string to satifsy extern reference in crt0.o if gem is
   not linked
 */
char __Ident_gem[1];

