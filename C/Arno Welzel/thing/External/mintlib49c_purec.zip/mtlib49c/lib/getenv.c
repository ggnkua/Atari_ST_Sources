/* functions for manipulating the environment */
/* written by Eric R. Smith and placed in the public domain */
/* 5/5/92 sb -- separated for efficiency, see also putenv.c */

#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

extern char **environ;

char *getenv(const char *tag)
{
	char **var;
	char *name;
	size_t len;

	if (!environ)
	  return 0;

	len = strlen (tag);

printf ( "getenv : %s %li ------------->", tag, len );


	for (var = environ; (name = *var) != 0; var++)
	{
/* printf ( "getenv : %s\r\n", name ); */
		if (!strncmp(name, tag, len))
		{
printf ( " 1 " );
			if ( name[len] == '=' )
			{
printf ( "< 2 -------------\r\n" );
			  return name+len+1;
			}
		}
/* printf ( "getenv : %s\r\n", name ); */
/*
		if (!strncmp(name, tag, len) && name[len] == '=')
			return name+len+1;
*/
	}
printf ( "< 3 -------------\r\n" );
	return 0;
}
