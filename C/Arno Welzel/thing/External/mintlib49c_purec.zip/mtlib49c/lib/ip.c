/* dummy ident string to satifsy extern reference in crt0.o if pml is
   not linked
 */
char __Ident_pml[1];

