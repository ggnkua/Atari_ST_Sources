#include "PatchLev.h"
char __Ident_gnulib[] = "$Patchlevel: MiNT library: " PatchLevel " $";
