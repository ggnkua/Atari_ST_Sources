/*
 *	This identifies the version of the MiNT library in this
 *	directory.
 */

#define PatchLevel "49c"
