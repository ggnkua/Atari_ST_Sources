#include <stdio.h>
#include <stdarg.h>
#include "lib.h"

int vprintf(const char *fmt, va_list args)
{
	return(_doprnt(fputc, stdout, fmt, args));
}
