#include <stdio.h>

main()
{
	printf("Hello world!\n");
	return 0;
}
