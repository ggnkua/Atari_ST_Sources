/* return absolute values */
#include <stdlib.h>

#ifdef labs
#undef labs
#endif

long labs(long x)
{
  return x < 0 ? -x : x;
}
