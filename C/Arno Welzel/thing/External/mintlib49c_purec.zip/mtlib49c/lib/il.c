/* dummy ident string to satifsy extern reference in crt0.o if libg is
   not linked
 */
char __Ident_libg[1];

