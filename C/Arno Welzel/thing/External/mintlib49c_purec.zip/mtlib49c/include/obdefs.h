#ifndef _OBDEFS_H
#define _OBDEFS_H

#include <gemfast.h>

#endif /* _OBDEFS_H */
