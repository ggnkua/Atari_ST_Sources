/* Indices du fichier ressource pour DEMO */

#define MENU1            0   /* Menu */
#define ACTION           5   /* TITLE dans l'arbre MENU1 */
#define MN1_INFO         10  /* STRING dans l'arbre MENU1 */
#define MN1_FS           20  /* STRING dans l'arbre MENU1 */
#define MN1_FD           21  /* STRING dans l'arbre MENU1 */
#define MN1_DUP          22  /* STRING dans l'arbre MENU1 */
#define MN1_FM           23  /* STRING dans l'arbre MENU1 */
#define MN1_FT           24  /* STRING dans l'arbre MENU1 */
#define MN1_FTM          25  /* STRING dans l'arbre MENU1 */
#define MN1_FMODAL       26  /* STRING dans l'arbre MENU1 */
#define MN1_FONTSEL      28  /* STRING dans l'arbre MENU1 */
#define MN1_FILESEL      29  /* STRING dans l'arbre MENU1 */
#define MN1_FRAME1       31  /* STRING dans l'arbre MENU1 */
#define MN1_FRAME2       32  /* STRING dans l'arbre MENU1 */
#define MN1_QUIT         34  /* STRING dans l'arbre MENU1 */
#define MN1_CYCLE        36  /* STRING dans l'arbre MENU1 */
#define MN1_CLOSE        37  /* STRING dans l'arbre MENU1 */
#define MN1_ICONIFY      38  /* STRING dans l'arbre MENU1 */
#define MN1_MAXIMISE     39  /* STRING dans l'arbre MENU1 */
#define MN1_REDRAW       40  /* STRING dans l'arbre MENU1 */
#define MN1_HIDE         41  /* STRING dans l'arbre MENU1 */
#define MN1_EXT          43  /* STRING dans l'arbre MENU1 */
#define MN1_WINFO        44  /* STRING dans l'arbre MENU1 */
#define MN1_AVSENDFILE   46  /* STRING dans l'arbre MENU1 */
#define MN1_AVOPENDIR    47  /* STRING dans l'arbre MENU1 */
#define MN1_AVSENDKEY    48  /* STRING dans l'arbre MENU1 */
#define MN1_AVVIEW       49  /* STRING dans l'arbre MENU1 */
#define MN1_AVSTATUS     51  /* STRING dans l'arbre MENU1 */
#define MN1_OP2          54  /* STRING dans l'arbre MENU1 */
#define MN1_READCONF     55  /* STRING dans l'arbre MENU1 */
#define MN1_CONF_WINDOM  57  /* STRING dans l'arbre MENU1 */
#define MN1_WINDOM       58  /* STRING dans l'arbre MENU1 */
#define MN1_OP3          60  /* STRING dans l'arbre MENU1 */

#define DIAL1            1   /* Formulaire/Dialogue */
#define DIAL1_COMPILER   5   /* TEXT dans l'arbre DIAL1 */

#define MENU2            2   /* Menu */
#define MN2_INFO         9   /* STRING dans l'arbre MENU2 */
#define MN2_FAST         11  /* STRING dans l'arbre MENU2 */
#define MN2_SLOW         12  /* STRING dans l'arbre MENU2 */
#define MN2_CIRCLE       14  /* STRING dans l'arbre MENU2 */
#define MN2_SQUARE       15  /* STRING dans l'arbre MENU2 */
#define MN2_ELLIPSE      16  /* STRING dans l'arbre MENU2 */
#define MN2_WHITE        18  /* STRING dans l'arbre MENU2 */
#define MN2_BLACK        19  /* STRING dans l'arbre MENU2 */
#define MN2_GREY         20  /* STRING dans l'arbre MENU2 */

#define DIAL2            3   /* Formulaire/Dialogue */
#define FOND1            2   /* BUTTON dans l'arbre DIAL2 */
#define FOND3            14  /* BUTTON dans l'arbre DIAL2 */
#define FOND4            19  /* BUTTON dans l'arbre DIAL2 */
#define DIAL2_BUSY       23  /* BUTTON dans l'arbre DIAL2 */
#define USERDIAL         30  /* BOX dans l'arbre DIAL2 */
#define DIAL2_TEST       31  /* BUTTON dans l'arbre DIAL2 */
#define DIAL2_ANNUL      32  /* BUTTON dans l'arbre DIAL2 */
#define DIAL2_OK         33  /* BUTTON dans l'arbre DIAL2 */
#define FOND2            34  /* BUTTON dans l'arbre DIAL2 */
#define ONG1             47  /* BUTTON dans l'arbre DIAL2 */
#define ONG2             48  /* BUTTON dans l'arbre DIAL2 */
#define ONG3             49  /* BUTTON dans l'arbre DIAL2 */
#define ONG4             50  /* BUTTON dans l'arbre DIAL2 */

#define ALR_QUIT         4   /* Formulaire/Dialogue */
#define ALR1_NON         4   /* BUTTON dans l'arbre ALR_QUIT */
#define ALR1_OUI         5   /* BUTTON dans l'arbre ALR_QUIT */

#define ALR2             5   /* Formulaire/Dialogue */

#define TOOL2            6   /* Formulaire/Dialogue */
#define TL2_FERM         1   /* BUTTON dans l'arbre TOOL2 */

#define DIAL3            7   /* Formulaire/Dialogue */
#define DL3_GEM          3   /* STRING dans l'arbre DIAL3 */
#define DL3_TYPE         5   /* STRING dans l'arbre DIAL3 */
#define DL3_ICON         7   /* STRING dans l'arbre DIAL3 */
#define DL3_MENU         9   /* STRING dans l'arbre DIAL3 */
#define DL3_TOOL         11  /* STRING dans l'arbre DIAL3 */
#define DL3_OUI          12  /* BUTTON dans l'arbre DIAL3 */

#define CONFIGURE        8   /* Formulaire/Dialogue */
#define CONF_OK          1   /* BUTTON dans l'arbre CONFIGURE */
#define CONF_APPL        2   /* BUTTON dans l'arbre CONFIGURE */
#define CONF_CANCEL      3   /* BUTTON dans l'arbre CONFIGURE */
#define CONF_BTRAME      5   /* STRING dans l'arbre CONFIGURE */
#define CONF_BCOL        6   /* STRING dans l'arbre CONFIGURE */
#define CONF_INSTALL     7   /* BUTTON dans l'arbre CONFIGURE */
#define CONF_BCOL_POP    8   /* BOX dans l'arbre CONFIGURE */
#define CONF_BTRAME_POP  9   /* BOX dans l'arbre CONFIGURE */
#define CONF_FCOL        11  /* STRING dans l'arbre CONFIGURE */
#define CONF_FCOL_POP    12  /* BOX dans l'arbre CONFIGURE */
#define CONF_FEPAI       14  /* FTEXT dans l'arbre CONFIGURE */
#define CONF_AUTOSAVE    16  /* BUTTON dans l'arbre CONFIGURE */
#define CONF_WINDSAVE    17  /* BUTTON dans l'arbre CONFIGURE */

#define FORM11           9   /* Formulaire/Dialogue */

#define MONO_ICON        10  /* Formulaire/Dialogue */

#define COLOR_ICON       11  /* Formulaire/Dialogue */

#define COULEUR          12  /* Formulaire/Dialogue */

#define TRAME            13  /* Formulaire/Dialogue */
#define POP_TRAME1       1   /* BOX dans l'arbre TRAME */

#define ATTRIBUT         14  /* Formulaire/Dialogue */
#define ATTR_ANNUL       1   /* BUTTON dans l'arbre ATTRIBUT */
#define ATTR_APPL        2   /* BUTTON dans l'arbre ATTRIBUT */
#define ATTR_OK          3   /* BUTTON dans l'arbre ATTRIBUT */
#define ATTR_FOND        5   /* BOX dans l'arbre ATTRIBUT */
#define ATTR_CLOSER      6   /* BOXCHAR dans l'arbre ATTRIBUT */
#define ATTR_FULLER      7   /* BOXCHAR dans l'arbre ATTRIBUT */
#define ATTR_RIGHT       8   /* BOXCHAR dans l'arbre ATTRIBUT */
#define ATTR_LEFT        9   /* BOXCHAR dans l'arbre ATTRIBUT */
#define ATTR_UP          10  /* BOXCHAR dans l'arbre ATTRIBUT */
#define ATTR_DOWN        11  /* BOXCHAR dans l'arbre ATTRIBUT */
#define ATTR_SIZER       12  /* BOXCHAR dans l'arbre ATTRIBUT */
#define ATTR_SMALLER     13  /* BOXCHAR dans l'arbre ATTRIBUT */
#define ATTR_NAME        14  /* FBOXTEXT dans l'arbre ATTRIBUT */
#define ATTR_INFO        15  /* FBOXTEXT dans l'arbre ATTRIBUT */
#define ATTR_HSLIDER     17  /* BOX dans l'arbre ATTRIBUT */
#define ATTR_VSLIDER     19  /* BOX dans l'arbre ATTRIBUT */

#define EXTRA            15  /* Formulaire/Dialogue */
#define EXTRA_ANNUL      2   /* BUTTON dans l'arbre EXTRA */
#define EXTRA_APPL       3   /* BUTTON dans l'arbre EXTRA */
#define EXTRA_OK         4   /* BUTTON dans l'arbre EXTRA */
#define EXTRA_GROW       5   /* BUTTON dans l'arbre EXTRA */
#define EXTRA_RIEN       7   /* BUTTON dans l'arbre EXTRA */
#define EXTRA_TIMER      8   /* BUTTON dans l'arbre EXTRA */
#define EXTRA_FORM       9   /* BUTTON dans l'arbre EXTRA */

#define TOOL1            16  /* Formulaire/Dialogue */
#define TL1_FERM         1   /* BUTTON dans l'arbre TOOL1 */
#define TL1_POPUP        3   /* BOXTEXT dans l'arbre TOOL1 */
#define TL1_CYCLE        4   /* BOXCHAR dans l'arbre TOOL1 */

#define POPUP1           17  /* Formulaire/Dialogue */

#define TEMPORAIRE       18  /* Formulaire/Dialogue */

#define COLORS           19  /* Formulaire/Dialogue */

#define CAPTUREKEY       20  /* Formulaire/Dialogue */

#define ALRT_SAVE_PAR    0   /* Chaine d'alerte */

#define ALRT_CLIC        1   /* Chaine d'alerte */

#define ALRT_KEY         2   /* Chaine d'alerte */

#define ALRT_END_CONS    3   /* Chaine d'alerte */

#define ALRT_WINCONF     4   /* Chaine d'alerte */

#define TYPE_FORM        5   /* Chaine libre */

#define TYPE_ANY         6   /* Chaine libre */

#define TYPE_ALIEN       7   /* Chaine libre */

#define ANS_YES          8   /* Chaine libre */

#define ANS_NO           9   /* Chaine libre */

#define WINDNAME         10  /* Chaine libre */

#define FSEL_TITLE       11  /* Chaine libre */

#define FONT_TITLE       12  /* Chaine libre */

#define FRAME_TITLE      13  /* Chaine libre */

#define SIMPLE_TITLE     14  /* Chaine libre */

#define FORM_TITLE       15  /* Chaine libre */

#define TOOLBAR_TITLE    16  /* Chaine libre */

#define MENU_TITLE       17  /* Chaine libre */

#define MFORM_TITLE      18  /* Chaine libre */

#define MENUTOOL_TITLE   19  /* Chaine libre */

#define BUILD_TITLE      20  /* Chaine libre */

#define INFO_TITLE       21  /* Chaine libre */

#define APP_NAME         22  /* Chaine libre */

#define CONF_TITLE       23  /* Chaine libre */

#define PATTERN1         0   /* Icone libre */
