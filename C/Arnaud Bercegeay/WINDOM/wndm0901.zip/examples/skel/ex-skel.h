/* Indices du fichier ressource pour EX-SKEL */

#define MENU_DESKTOP     0   /* Menu */
#define INFO_APP         7   /* STRING dans l'arbre MENU_DESKTOP */
#define LOAD             16  /* STRING dans l'arbre MENU_DESKTOP */
#define QUIT             18  /* STRING dans l'arbre MENU_DESKTOP */

#define ICON             1   /* Formulaire/Dialogue */

#define ALRT_INFO        0   /* Chaine d'alerte */
