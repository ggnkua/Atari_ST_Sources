/* Indices du fichier ressource pour EX_POPUP */

#define FRM1             0   /* Formulaire/Dialogue */
#define BUT_QUIT         2   /* BUTTON dans l'arbre FRM1 */
#define BUT_POP1         5   /* BUTTON dans l'arbre FRM1 */
#define BUT_POP2         9   /* BUTTON dans l'arbre FRM1 */
#define BUT_PREF         14  /* BUTTON dans l'arbre FRM1 */
#define BUT_WINCONF      15  /* BUTTON dans l'arbre FRM1 */
#define BUT_POP3         18  /* BUTTON dans l'arbre FRM1 */

#define POP1             1   /* Formulaire/Dialogue */

#define PREFS            2   /* Formulaire/Dialogue */
#define PREF_APPLY       2   /* BUTTON dans l'arbre PREFS */
#define PREF_CANCEL      6   /* BUTTON dans l'arbre PREFS */
#define BUT_3D           8   /* BUTTON dans l'arbre PREFS */
#define POP_BGCOLOR      13  /* BOX dans l'arbre PREFS */
#define POP_BGPATT       14  /* BOX dans l'arbre PREFS */
#define POP_BDCOLOR      15  /* BOX dans l'arbre PREFS */
#define POP_FRCOLOR      16  /* BOX dans l'arbre PREFS */
#define BUT_WINDOW       18  /* BUTTON dans l'arbre PREFS */

#define POPCOLOR         3   /* Formulaire/Dialogue */

#define POPSTYLE         4   /* Formulaire/Dialogue */
#define POP_TRAME1       1   /* BOX dans l'arbre POPSTYLE */
