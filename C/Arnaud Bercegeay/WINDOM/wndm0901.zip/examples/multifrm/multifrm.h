/* Indices du fichier ressource pour MULTIFRM */

#define FORM1            0   /* Formulaire/Dialogue */
#define CANCEL           1   /* BUTTON dans l'arbre FORM1 */
#define FOND1            2   /* BUTTON dans l'arbre FORM1 */
#define OK               5   /* BUTTON dans l'arbre FORM1 */
#define FOND2            6   /* BUTTON dans l'arbre FORM1 */
#define FOND3            9   /* BUTTON dans l'arbre FORM1 */
#define BUT1             12  /* BUTTON dans l'arbre FORM1 */
#define BUT2             13  /* BUTTON dans l'arbre FORM1 */
#define BUT3             14  /* BUTTON dans l'arbre FORM1 */
