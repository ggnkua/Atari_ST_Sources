/* Indices du fichier ressource pour TEST */

#define FORM1            0   /* Formulaire/Dialogue */
#define OK               1   /* BUTTON dans l'arbre FORM1 */
#define APPLIQUE         3   /* BUTTON dans l'arbre FORM1 */
#define BHLP_DELAY       4   /* FTEXT dans l'arbre FORM1 */
#define BHLP_WINDOWS     5   /* BUTTON dans l'arbre FORM1 */
#define BHLP_FONTES      6   /* BUTTON dans l'arbre FORM1 */
#define BHLP_SENDKEY     7   /* BUTTON dans l'arbre FORM1 */
#define BHLP_DEMON       8   /* BUTTON dans l'arbre FORM1 */
#define BHLP_TOP         9   /* BUTTON dans l'arbre FORM1 */

#define CHOIX_FORM       0   /* Chaine d'alerte */

#define NO_BUBBLE        1   /* Chaine d'alerte */

#define H_OK             2   /* Chaine libre */

#define H_APPLIQUE       3   /* Chaine libre */

#define H_WINDOWS        4   /* Chaine libre */

#define H_FONTES         5   /* Chaine libre */

#define H_DEMON          6   /* Chaine libre */

#define H_TOP            7   /* Chaine libre */

#define H_SENDKEY        8   /* Chaine libre */

#define H_DELAY          9   /* Chaine libre */

#define H_FOND           10  /* Chaine libre */
