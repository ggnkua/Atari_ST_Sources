/* Indices du fichier ressource pour SLIDER */

#define FORM1            0   /* Formulaire/Dialogue */
#define F1_CLOSE         1   /* BUTTON dans l'arbre FORM1 */
#define PERE_SLD         3   /* BOX dans l'arbre FORM1 */
#define SLIDER           4   /* BOX dans l'arbre FORM1 */
#define F1_TR            5   /* BUTTON dans l'arbre FORM1 */
#define F1_FIELD         6   /* STRING dans l'arbre FORM1 */
