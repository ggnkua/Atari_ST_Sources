/* Indices du fichier ressource pour TSTFRAME */

#define TOOL1            0   /* Formulaire/Dialogue */
