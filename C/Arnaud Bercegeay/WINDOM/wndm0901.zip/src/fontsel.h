/* Indices du fichier ressource pour FONTSEL */

#define FONTSEL          0   /* Formulaire/Dialogue */
#define FONT_DRAW        1   /* BOX dans l'arbre FONTSEL */
#define FONT_USER        2   /* IBOX dans l'arbre FONTSEL */
#define FONT_OK          3   /* BUTTON dans l'arbre FONTSEL */
#define FONT_CANCEL      4   /* BUTTON dans l'arbre FONTSEL */
#define FONT_DN          6   /* BOXCHAR dans l'arbre FONTSEL */
#define FONT_UP          7   /* BOXCHAR dans l'arbre FONTSEL */
#define FONT_BACK        8   /* BOX dans l'arbre FONTSEL */
#define FONT1            9   /* STRING dans l'arbre FONTSEL */
#define FONT2            10  /* STRING dans l'arbre FONTSEL */
#define FONT3            11  /* STRING dans l'arbre FONTSEL */
#define FONT4            12  /* STRING dans l'arbre FONTSEL */
#define FONT5            13  /* STRING dans l'arbre FONTSEL */
#define FONT6            14  /* STRING dans l'arbre FONTSEL */
#define FONT7            15  /* STRING dans l'arbre FONTSEL */
#define FONT8            16  /* STRING dans l'arbre FONTSEL */
#define FONT_SIZE        17  /* FBOXTEXT dans l'arbre FONTSEL */
#define IDFONT           18  /* FTEXT dans l'arbre FONTSEL */
