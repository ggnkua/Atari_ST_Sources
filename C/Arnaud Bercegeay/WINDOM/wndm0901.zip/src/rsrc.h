/*
 *	WinDom - Librairie ressource - header
 *
 */

#define NO_RSC	0
#define EXT_RSC 1
#define INT_RSC 2