/* Indices du fichier ressource pour MNSCROLL */

#define MNSCROLL         0   /* Formulaire/Dialogue */
#define MENULF           1   /* BOXCHAR dans l'arbre MNSCROLL */
#define MENURT           2   /* BOXCHAR dans l'arbre MNSCROLL */
