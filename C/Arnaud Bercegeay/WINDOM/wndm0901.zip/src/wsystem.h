/* Indices du fichier ressource pour WSYSTEM */

#define USERDEF          0   /* Formulaire/Dialogue */
#define LRAD             1   /* USERDEF dans l'arbre USERDEF */
#define LBUT             2   /* USERDEF dans l'arbre USERDEF */
#define MLRAD            3   /* USERDEF dans l'arbre USERDEF */
#define MLBUT            4   /* USERDEF dans l'arbre USERDEF */
#define HRAD             5   /* USERDEF dans l'arbre USERDEF */
#define HBUT             6   /* USERDEF dans l'arbre USERDEF */
#define MHBUT            7   /* USERDEF dans l'arbre USERDEF */
#define MHRAD            8   /* USERDEF dans l'arbre USERDEF */
#define HCIR             9   /* USERDEF dans l'arbre USERDEF */
#define LCIR             10  /* USERDEF dans l'arbre USERDEF */
#define MHCIR            11  /* USERDEF dans l'arbre USERDEF */
#define MLCIR            12  /* USERDEF dans l'arbre USERDEF */
#define HBUT2            13  /* USERDEF dans l'arbre USERDEF */
#define HRAD2            14  /* USERDEF dans l'arbre USERDEF */
#define LRAD2            15  /* USERDEF dans l'arbre USERDEF */
#define MHBUT2           16  /* USERDEF dans l'arbre USERDEF */
#define MHRAD2           17  /* USERDEF dans l'arbre USERDEF */
#define MLRAD2           18  /* USERDEF dans l'arbre USERDEF */
#define LBUT2            19  /* USERDEF dans l'arbre USERDEF */
#define MLBUT2           20  /* USERDEF dans l'arbre USERDEF */
