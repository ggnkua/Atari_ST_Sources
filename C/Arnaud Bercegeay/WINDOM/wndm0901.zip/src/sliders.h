/* Indices du fichier ressource pour SLIDERS */

#define FRAME_SLIDER     0   /* Formulaire/Dialogue */
#define M_V_BG           1   /* BOX dans l'arbre FRAME_SLIDER */
#define M_V_UP           2   /* BOXCHAR dans l'arbre FRAME_SLIDER */
#define M_V_DW           3   /* BOXCHAR dans l'arbre FRAME_SLIDER */
#define M_V_PG           4   /* BOX dans l'arbre FRAME_SLIDER */
#define M_V_SL           5   /* BOX dans l'arbre FRAME_SLIDER */
#define M_H_BG           6   /* BOX dans l'arbre FRAME_SLIDER */
#define M_H_LF           7   /* BOXCHAR dans l'arbre FRAME_SLIDER */
#define M_H_RT           8   /* BOXCHAR dans l'arbre FRAME_SLIDER */
#define M_H_PG           9   /* BOX dans l'arbre FRAME_SLIDER */
#define M_H_SL           10  /* BOX dans l'arbre FRAME_SLIDER */
#define M_SZ             11  /* BOXCHAR dans l'arbre FRAME_SLIDER */
#define M_INFO           12  /* BOXTEXT dans l'arbre FRAME_SLIDER */
