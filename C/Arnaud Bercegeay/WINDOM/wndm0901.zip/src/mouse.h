/* Indices du fichier ressource pour MOUSE */

#define MOUSE            0   /* Formulaire/Dialogue */
