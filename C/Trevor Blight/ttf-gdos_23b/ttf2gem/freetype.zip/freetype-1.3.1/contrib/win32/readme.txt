The purpose of this application is to serve as a running environment for 
some of the freetype project test programs:
currently available programa aree ftdump,ftlint,,ftstring,ftview;
others may be convinced to run but you may need to change the source
code to avoid duplicate problems with the linker.
This work has been based on a large amount of guesswork		
and a small amount of  my (little) spare time;
however it seems to be	working pretty well as far as I can tell
( -g -r options are not working but I don't care 'bout them).
It can be compiled both under MS VC++ Version 4.X and Version 5.
and has been tested under Windows 95 & NT 4.0 .

Have Fun .
 Giancarlo Ramat 
  (gcramat@radiostudio.it) 

[Please note that all files are archived in Unix LF format (except
testw32.mdp which is a binary file).  If necessary, use e.g. unzip's `-a'
flag to convert to MSDOS CR/LF convention.]
