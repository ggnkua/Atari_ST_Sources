/*
 * Extremely bodged startup - after all there's no point in implementing the
 * whole thing if all it's going to do is mangle GFS's stack and registers.
 *
 * I've no real idea how much stack pug actually requires. The MWC default is
 * a measly 2K so I don't forsee any problems with it though - it probably uses
 * under 500 bytes.
*/
#include <gem.h>
#include "pug.h"
#include "main.h"

#include <basepage.h>
#include <osbind.h>
#include <mem.h>
#include <string.h>

/*
 * The first bit. This is responsible for loading the overlay and locating the
 * base address of the functions. This is the only bit I haven't stripped down.
*/
ulong
Pug(pug_mod,pfpp)
char	pug_mod[];	/* the overlay name - ie PUG_MOD */
PUGFUNC	**pfpp;		/* the address to which the function base address is
			written - ie &gl_pfp much akin to stik's */
{slong		r;
 BASEPAGE	*bp;
 slong		i;
 char		*p,
		s[256];
 sint		h;

 /* ?module exists in current directory? */
 if ((h = Fopen(pug_mod,0)) < 0)	{/* no */
	/* get executable directory */
	shel_read(&s[0],&s[128]);
	/* remove executable name */
	if	(
		((p = strrchr(s,'\\')) == NULL) &&
		((p = strchr(s,':')) == NULL)
		)

		p = &s[-1]
	;
	/* add module name */
	strcpy(&p[1],pug_mod);
	}
 else	{
	Fclose(h);
	strcpy(s,pug_mod);
 }

 /* ?module overlay loaded? */
 if ((r = Pexec(3,s,NULL,NULL)) < 0)	{/* no */
	sprintf(s,"[3][Pexec(3) failed|Code %d|File %s][Typical]",
		(int)r,pug_mod
		)
	;
	form_alert(1,s);
	return 0;
 }

 /* execute module startup (Ptermres to hand back unused TPA) */
 bp = (BASEPAGE*)r;
 Pexec(4,NULL,bp,NULL);

 /* search module data segment for header */
 /* kludge for development version */
 /* saves manually ensuring header is linked at start of data segment */
 p = (char*)bp->p_dbase;
 for (i = 0; i < bp->p_dlen; i++)	{
	if (memcmp(p + i,PUG_HDR_TXT,PUG_HDR_LEN) == 0)	{/* header found */
		/* set function pointer structure */
		*pfpp = p + i + PUG_HDR_LEN + PUG_VER_LEN;
		/* version number */
		return *((ulong*)(p + i + PUG_HDR_LEN));
	}
 }

 sprintf(s,"[3][PUG Overlay %s|Cannot locate header][Typical]",pug_mod);
 form_alert(1,s);
 return 0;
}

/*----------------------------------------------------------------------------*/
/*
 * Now that's out of the way, we finally get to the program. I use a couple of
 * templates normally but not here - it's been stripped down again, we don't
 * need all the usual error checking ...
*/

/* load the function base address here, erm well into the GFA equivilent! */
static PUGFUNC	*gl_pfp;

/* main.rsc has 4 trees, each to go in a window so we need 4 elements of type
  PUG to hold them ...
*/
#define	NUM_WINDOWS	4
/* declare out own indices into the PUG array ... */
#define	F_ABOUT		0
#define	F_F0		1
#define	F_F1		2
#define	F_F2		3

static EVM	evm;			/* for Evnt_Multi() */
static int	msg[8],			/* ditto */
		wdi,
		cwd	=NUM_WINDOWS;

/* this is the data pointer around which everything revolves ... */
static PUG	*wd;
static OBJECT	*menu;		/* our trivial menu bar */
static uint	events;
static bool	done	=false;

/*----------------- mundane menu bar handling --------------------------------*/
static void
Hndl_DESK()
{
 switch (msg[4])	{
	case M0ABOUT:
	/* this opens a window around the current position of the tree */
	/* if the window is already open it tops it. It is better to think */
	/* of the window following the tree around and not vice-versa */
	pug_new_dial(&evm,wd,F_ABOUT,cwd,NULL);
	break;

	default:
	break;
 }
}

static void
Hndl_FILE()
{
 switch (msg[4])	{
	/* ditto for the other trees ... */
	case M0TREEF0:	pug_new_dial(&evm,wd,F_F0,cwd,NULL);	break;
	case M0TREEF1:	pug_new_dial(&evm,wd,F_F1,cwd,NULL);	break;
	case M0TREEF2:	pug_new_dial(&evm,wd,F_F2,cwd,NULL);	break;
	case M0QUIT:	done = true;				break;
	default:						break;
 }
}

static void
Hndl_MENU()
{
 switch (msg[3])	{
	case M0DESK:	Hndl_DESK();	break;
	case M0FILE:	Hndl_FILE();	break;
	default:			break;
 }
 menu_tnormal(menu,msg[3],TRUE);
}
/*------------------------- mesag handling -----------------------------------*/
/*
 * pug does the windows so we are left with just the menubar ...
*/
static void
Hndl_MESAG()
{
 switch (msg[0])	{
	case MN_SELECTED:	Hndl_MENU();	break;
	default:				break;
 }
}

/*
 * pug treats user interaction with a tree in a psuedo message way. One thing
 * it does it set this flag when the user interacts with that tree. Another
 * thing it does is check them on entry and if any are set it returns
 * immediately which has the dubious result of hanging the program. This is
 * worth the slight trouble it sometimes causes because a program can press
 * its own buttons transparently to itself!
*/
static void
Hndl_ACT()
{
 /* groovy - as these are all simple windows we can handle all 4 of them */
 /* with the same code. */

 wd[wdi].wd_act = false;

 /* close window if the user interacts with an object which has */
 /* suitable exit status */
 pug_old_dial(&evm,wd,wdi,cwd);

 /* now unselect it. If the window happened to have still been open it will */
 /* be visually unselected also. */
 pug_obstate(wd,wdi,wd[wdi].wd_obi,~SELECTED,NORMAL);
}

main()
{
 appl_init();

 /* load and initialise the functions as defined in pug.h */
 /* will return the version number is successful, zero otherwise */
 /* major version in high byte, minor in low byte about 0.8 or 0.9 atm */
 if (Pug(PUG_MOD,&gl_pfp) == 0)	goto main_0;

 /* pug is initialised but we need to convince gem that the main app and the */
 /* overlay are one and the same thing. */
 pug_enable();

 /* set default evnt_multi() parameters and msg[] buffer */
 Evnt_Multi(&evm,true,msg);

 if (!rsrc_load("main.rsc")) 	{
 	form_alert(1,"[3][No RSC][Typical]");
	goto main_1;
 }

 /* dynamically allocate the PUG array with 4 (ie cwd) elements */
 /* I could have made this fixed as everything is known at compile time but */
 /* decided to make this call behave like realloc() which allows the */
 /* possibility to dump and create trees at will */
 if ((wd = pug_mem(NULL,0,cwd)) == NULL)	{
 	form_alert(1,"[3][Not enough memory][Typical]");
 	goto main_2;
 }

 rsrc_gaddr(R_TREE,M0,&menu);

 /* load the trees into the PUG array */
 rsrc_gaddr(R_TREE,FABOUT,&wd[F_ABOUT].wd_ob);
 rsrc_gaddr(R_TREE,F0,&wd[F_F0].wd_ob);
 rsrc_gaddr(R_TREE,F1,&wd[F_F1].wd_ob);
 rsrc_gaddr(R_TREE,F2,&wd[F_F2].wd_ob);

 /* ensure the trees will be centered, the default is to use the settings */
 /* in the resource. In reality there are a few more pug calls here which */
 /* can produce such things as keyboard shortcut underlining and */
 /* automatically open windows that were open at the time we last quit */
 for (wdi = 0; wdi < cwd; wdi += 1)	{
 	pug_centre(wd,wdi);
 }

 menu_bar(menu,TRUE); 
 while (!done)	{
	/* this is it, it simply replaces evnt_multi(). All the work gets */
	/* done in here. It only returns when it has something useful for */
	/* the program to do - ie something it cannot figure out or has been */
	/* ordered not to figure out. */
	events = pug_dialogue(&evm,wd,cwd);

	if (events & MU_MESAG)	Hndl_MESAG();

	/* check for user interaction */
	for (wdi = 0; wdi < cwd; wdi += 1)	{
		if (wd[wdi].wd_act)	Hndl_ACT();
	}
 }
 menu_bar(menu,FALSE);

 /* shut down any open windows if they were open */
 for (wdi = 0; wdi < cwd; wdi += 1)
 	 pug_old_dial(&evm,wd,wdi,cwd)
 ;

 /* resize the PUG array down to zero, ie release it */
 pug_mem(wd,cwd,0);
 
main_2:
 rsrc_free();

main_1:
 /* unhook from gem */
 pug_disable();

main_0:

 appl_exit();
 return 0;
}
