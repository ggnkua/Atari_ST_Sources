#include <gem.h>
#include "evnt.h"

/*
 * evnt_multi() in a structure.
 *
 * when the example issues Evnt_Multi(&evm,true,msg) implement the "init_flg"
 * code below.
*/
int
Evnt_Multi(m,init_flg,msgbuf)
EVM	*m;
bool	init_flg;
int	*msgbuf;
{
 if (init_flg)	{
	m->evm_event = MU_MESAG;
	m->evm_clicks = 2;
	m->evm_button = 1;
	m->evm_bstate = 3;
	m->evm_m1io = 0;
	m->evm_m1.x =	m->evm_m1.y =	m->evm_m1.w = m->evm_m1.h = 1;
	m->evm_m2io = 1;
	m->evm_m2.x =	m->evm_m2.y =	m->evm_m2.w = m->evm_m2.h = 1;
	m->evm_msg = msgbuf;
	m->evm_time = 0;

	return 0;
 }

 if (m->evm_msg == NULL)	{
	form_alert(1,"[3][Evnt_Multi()|Not initialised][Fatal]");
	return 0;
 }

/* issue the call, ie Evnt_Multi(&evm,false);
 * The only difference here is I've taken the opportunity to
 * merge the timer value back into a long. The example does not use it so
 * it shouldn't be any trouble.
*/
 return evnt_multi(
		m->evm_event,
		m->evm_clicks, m->evm_button, m->evm_bstate,
		m->evm_m1io, m->evm_m1, m->evm_m2io, m->evm_m2,
		m->evm_msg,
		(uint)(m->evm_time & 0xffff), (uint)(m->evm_time >> 16),
		&m->evm_mousex, &m->evm_mousey, &m->evm_mbutton,
		&m->evm_kstate, &m->evm_keycode,
		&m->evm_clicked
		)
 ;
}
