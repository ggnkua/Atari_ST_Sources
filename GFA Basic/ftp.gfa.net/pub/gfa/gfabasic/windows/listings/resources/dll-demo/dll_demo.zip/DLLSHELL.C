// Borland C++ - (C) Copyright 1991 by Borland International

// Example program used to demonstrate DLL's. This file one of the
// files used to build BITMAP.DLL which is used in the DLLDEMO program.

#include <windows.h>
#include <stdio.h>

// Turn off warning: Parameter '' is never used
#pragma argsused


extern "C"
{
BOOL FAR PASCAL _export DlgProc (HWND, UINT, UINT, LONG) ;
BOOL FAR PASCAL _export PrintDlgProc (HWND, UINT , UINT , LONG);
BOOL FAR PASCAL _export AbortProc (HDC, short);

}

int FAR PASCAL LibMain( HANDLE hInstance, WORD wDataSegment,
                                   WORD wHeapSize, LPSTR lpszCmdLine )
{
   
    if ( wHeapSize != 0 )
        UnlockData( 0 );
    return 1;  
}


int FAR PASCAL WEP ( int bSystemExit )
{
	return 1;
}

BOOL FAR PASCAL _export DlgProc (HWND hDlg, UINT message, UINT wParam,
                                                               LONG lParam)
     {
	 switch (message)
	 {
	 case WM_COMMAND:
		SendMessage( GetParent(hDlg), message, wParam,lParam);

	 case WM_MOVE:
  		SendMessage( GetParent(hDlg), message, wParam,lParam);

	 case WM_MOUSEMOVE:
	 	SendMessage( GetParent(hDlg), message, wParam,lParam);

	 case WM_LBUTTONDOWN:
	 	SendMessage( GetParent(hDlg), message, wParam,lParam);

	 case WM_RBUTTONDOWN:
	 	SendMessage( GetParent(hDlg), message, wParam,lParam);

	 case WM_INITDIALOG:
		return TRUE;

	 case WM_KEYDOWN:
	 	SendMessage( GetParent(hDlg), message, wParam,lParam);
		return 0;
//	 default:
//	    return (DefWindowProc(hDlg, message, wParam, lParam));
	 }
	
	 return FALSE;
	 }




BOOL   bUserAbort ;
HWND   hDlgPrint ;


BOOL FAR PASCAL _export PrintDlgProc (HWND hDlg, UINT message, UINT wParam,
															   LONG lParam)
     {
     switch (message)
          {
          case WM_INITDIALOG:
			   EnableMenuItem (GetSystemMenu (hDlg, FALSE), SC_CLOSE,
                                                            MF_GRAYED) ;
               return TRUE ;

          case WM_COMMAND:
               bUserAbort = TRUE ;
               EnableWindow (GetParent (hDlg), TRUE) ;
               DestroyWindow (hDlg) ;
               hDlgPrint = 0 ;
               return TRUE ;
          }
     return FALSE ;
     }          

BOOL FAR PASCAL _export AbortProc (HDC hdcPrn, short nCode)
	 {
     MSG   msg ;

     while (!bUserAbort && PeekMessage (&msg, NULL, 0, 0, PM_REMOVE))
          {
          if (!hDlgPrint || !IsDialogMessage (hDlgPrint, &msg))
               {
               TranslateMessage (&msg) ;
               DispatchMessage (&msg) ;
               }
          }
     return !bUserAbort ;
     }
