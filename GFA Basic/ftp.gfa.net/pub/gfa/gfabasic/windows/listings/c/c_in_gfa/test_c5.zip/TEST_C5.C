
    /*   This C-File gets linked to GFA-BASIC for Windows Compiler
         TEST_C5.GFW     (  <<    O-Ton GFA )     */
  
    /*    Als Compiler wurde MS Visual C++ 1.0  (Hausfrauen-Ausgabe mit Obergrenze 286er)
          verwendet.
          Projekttyp: Quickwin
          Speichermodell :  Large   ( Wichtig, sonst geht nichts !!! )
          Nicht anfassen : GFA.h  sowie _near und _far  .
          
          Zum Linken habe ich der Einfachheit halber auch gleich VC 1.0 genommen, nachdem ich vorher
          ~gfa.obj mit wgen.exe (und entsprechenden Fehlermeldungen beim Link-Versuch ) erzeugte.
          Nat�rlich geht das auch andersherum, wenn man die Kommandozeilenversion gen.exe nimmt
          und au�er glib.lib die entsprechende C-Bibliothek ( hier llibcewq.lib) angibt.         */
    
    
     #include <string.h>

      void pascal TestC( short a[] , double a1[], long a2[], char a3[], short *b1, double *c1, long *d1 )


{
   /* Beispiel f�r Anpassung an ein bestehendes C-Programm .
      Da Felder ( inclusive Text-Variable in GFA ! )  ohnehin �ber Pointer  angesprochen werden,
      sind im C-Teil nur die Variablen gegebenenfalls umzusetzen ,um ein Originalprogramm so
      wenig wie m�glich zu �ndern .                                                                                       */
     
     /* -----------------  Umsetzung auf  b ,c , d ----------------------------- */
    
         short b;
         double c;
         long d;
         
         
         b=*b1 ;
         c=*c1;
         d=*d1;

     /* -----------------------------------------------------------------------------------------*/   
   
       b=b+a[3] ;
     
       a1[3]=55.789; 
  
       a2[3]=234;
    
       a[3]=107;
    
       d=77;
      
       c=2*c;
      
      strcpy(a3," Zwanzig ");
 
     /*------------ Und zur�ck --------------------------------------------------------------------- */
    
     *b1=b;
     *c1=c;
     *d1=d;

    /* ----------------------------------------------------------------------------------------------------------------------------------  */
       
}
 

