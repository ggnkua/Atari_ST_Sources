/*
    This C-File gets linked to GFA-BASIC for Windows Compiler
    TESTC.GFW
*/
#include <windows.h>

void far pascal TestC(HDC dc,int x,int y,int w,int h,int wid)
{
    HPEN OldPen;
    HPEN Black = GetStockObject(BLACK_PEN);
    HPEN White = GetStockObject(WHITE_PEN);
    HPEN tmp;
    OldPen = SelectObject(dc,Black);
    for(;;)
	{
	MoveTo(dc,x+w,y);
	LineTo(dc,x+w,y+w);
	LineTo(dc,x,y+h);
	SelectObject(dc,White);
	LineTo(dc,x,y);
	LineTo(dc,x+w,y);
	if(--wid < 0) break;
	x++; y++; w -= 2; h -= 2;
	tmp = Black; Black = White; White = tmp;
	}
    SelectObject(dc,OldPen);
}
