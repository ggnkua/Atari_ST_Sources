/* Psycho.c Screensaver Psycho nach diversen Transformationen HT '97*/
/* modifiziertes Listing nach Gerhard Schild */
/* passend als C - Objekt f�r GFA Basic - klappt bestens */
/* wenn schon C, dann mal komplett mit richtig drum und dran...*/
/* Psycho (wie der Name) ist labil und startet nicht immer optimal, z.B.
   wenn zuvor ein anderes GFA Basic Programm lief (?)*/

/* compilieren mit sc -a2 -ms (-cod) -c -S -2 psycho.c */
		 /*    = word+ small+ 386/87-	*/

#define TITLE "Psycho aus C in GFA Basic HT '97"
#define N 48
#define DX 2
#define RATEMIN 3
#define RATEMAX 50
#define CHANGERATE 2000

#include <windows.h>
#include <gfa.h>

#define MOUSETHRESHOLD 25

#ifndef SC_SCREENSAVE
	#define SC_SCREENSAVE 0xF140
#endif

HANDLE hInstance;
MSG     msg;
HWND    hwnd;
int rr;


long far pascal WndProc(HWND hwnd, unsigned msg, unsigned wp, LONG lp);
LPLOGPALETTE MakePalette(WORD n);
BYTE MakeColor(WORD i);
BOOL Sync(DWORD *pdwStart, WORD wmsTime);
GFUNCN P_CMDINFO();  /*retval Procedure... = Function */

typedef struct tagTIMERINFO {
	DWORD dwSize;
	DWORD dwmsSinceStart;
	DWORD dwmsThisVM;
} TIMERINFO;

main(){/* nix f�r dos*/}

int far pascal WinMain(HANDLE hThisInstance, HANDLE hPrevInstance,
		LPSTR lpCmdLine, int CmdShow)

{	
	if (hPrevInstance) return 1;
	hInstance=hThisInstance;
	blackbox(WndProc); 
	return 0;
}

long far pascal DefSaverProc(HWND hwnd, unsigned msg, unsigned wp, LONG lp)
{
	switch(msg)
	{
	case WM_CREATE:
		ShowCursor(FALSE);
		break;
	case WM_DESTROY:
		ShowCursor(TRUE);
		PostQuitMessage(0);
		break;
	case WM_SYSCOMMAND:
		if(wp==SC_SCREENSAVE)
		return NULL;
		break;
	case WM_ACTIVATEAPP:
		if(wp) break;
	case WM_KEYDOWN:
	case WM_SYSKEYDOWN:
	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
		PostMessage(hwnd,WM_CLOSE,0,0L);
		return NULL;
	case WM_MOUSEMOVE:
	{
	static union {
		long l; RECT r; POINT p[2];
	} bounds;
	if(bounds.l==0L)
	{
		bounds.p[0]=bounds.p[1]=MAKEPOINT(lp);
		InflateRect(&bounds.r, MOUSETHRESHOLD, MOUSETHRESHOLD);
	}
	else if (!PtInRect(&bounds.r, MAKEPOINT(lp)))
		PostMessage(hwnd,WM_CLOSE,0,0L);
	break;
	}
   }
   return DefWindowProc(hwnd,msg,wp,lp);
}

int blackbox(long (far pascal *lpfnWnd)())
{
	WNDCLASS wc;
	
	wc.style=CS_OWNDC;
	wc.hInstance=hInstance;
	wc.lpfnWndProc=lpfnWnd;
	wc.hbrBackground=GetStockObject(BLACK_BRUSH);
	wc.lpszClassName="BlackBox";
	RegisterClass(&wc);
	rr=P_CMDINFO();  /*lpCmdLine wird elegent von GFA Basic erledigt */
	if (rr==1)
	{
	MessageBox(NULL,"Psycho hat keine Einstellungen. Er sollte keinesfalls von Epilepsie gef�hrdeten Personen benutzt werden",
		TITLE,MB_OK|MB_ICONSTOP);
		return 1;
	}
	CreateWindow("BlackBox","",WS_POPUP|WS_MAXIMIZE|WS_VISIBLE,
		0,0,0,0,NULL,NULL,hInstance,NULL);
	
	while (GetMessage(&msg,NULL,0,0))
		DispatchMessage(&msg);
		return msg.wParam;
}

BOOL MyYield(void)
{
	MSG msg;
	while(PeekMessage(&msg,NULL,0,0,PM_REMOVE))
	{
	if(msg.message==WM_QUIT)
	{
		PostQuitMessage(msg.wParam);
		return TRUE;
	}
	else
	DispatchMessage(&msg);
    }
    return FALSE;
}	

BOOL far pascal TimerCount(TIMERINFO FAR *);


long far pascal WndProc(HWND hwnd, unsigned msg, unsigned wp, LONG lp)
{
	static HPALETTE hPal;
	PAINTSTRUCT ps;
	HPEN hOldPen;
	HDC hdc;
	DWORD dwTime;
	int nRate=RATEMAX, nDelta=-1, nTime=0, r, x0, y0;
	switch(msg)
	{
	case WM_CREATE:
	hdc=GetDC(hwnd);
	if(!(GetDeviceCaps(hdc, RASTERCAPS)&RC_PALETTE))
	{
		ReleaseDC(hwnd, hdc);
		MessageBox(hwnd, "Graphik Karte macht nicht mit",TITLE,MB_OK|MB_ICONSTOP);
		DestroyWindow(hwnd);
		break;
	}
	else
	{
		hPal=CreatePalette(MakePalette(0));
		SelectPalette(hdc, hPal, FALSE);
		RealizePalette(hdc);
		SelectObject(hdc, GetStockObject(HOLLOW_BRUSH));
	}
		ReleaseDC(hwnd, hdc);
		break;
	case WM_DESTROY:
		DeleteObject(hPal);
		break;
	case WM_PAINT:
		BeginPaint(hwnd, &ps);
		EndPaint(hwnd, &ps);
		x0=ps.rcPaint.right/2;
		y0=ps.rcPaint.bottom/2;
		for (r=1; (long)r*r<(long)x0*x0+(long)y0*y0; r+=DX)
		{
			hdc=GetDC(hwnd);
			hOldPen=SelectObject(hdc, CreatePen(PS_SOLID, DX, 
				PALETTEINDEX((r/DX)%N)));
			Ellipse(hdc, x0-r, y0-r, x0+r, y0+r);
			DeleteObject(SelectObject(hdc, hOldPen));
			ReleaseDC(hwnd, hdc);
			if (MyYield()) return NULL;
		}
		for (r=0; !Sync(&dwTime, nRate); r++)
		{
			nTime+=nRate;
			if(nTime>CHANGERATE)
			{
			nTime=0;
			nRate+=nDelta;
			if (nRate<RATEMIN||nRate>RATEMAX)
			nDelta*=-1;
			}
		hdc=GetDC(hwnd);
		AnimatePalette(hPal, 0, N, MakePalette(r)->palPalEntry);
		ReleaseDC(hwnd, hdc);
		}
		return NULL;
	}
	return CallWindowProc((FARPROC) DefSaverProc,hwnd, msg, wp, lp);
 	    
}

LPLOGPALETTE MakePalette(WORD n)
{
	static char buffer[sizeof(LOGPALETTE)+(N-1)*sizeof(PALETTEENTRY)];
	WORD i;
	LPLOGPALETTE lpPal=(LPLOGPALETTE) buffer;
	lpPal->palVersion=0x300;
	lpPal->palNumEntries=N;
		
	for (i=0; i<N;  i++)
	{
		lpPal->palPalEntry[i].peRed=MakeColor(i+n);
		lpPal->palPalEntry[i].peGreen = MakeColor(i+n+N/6);
		lpPal->palPalEntry[i].peBlue = MakeColor(i+n+N/3);
		lpPal->palPalEntry[i].peFlags = PC_RESERVED;
	}
	return lpPal;
		
}

BYTE MakeColor(WORD i)
{
	i%=N;
	if(i<N/3) return i*(255*3/N);
	else if (i<2*N/3) return (2*N/3-i)*(255*3/N);
	else
	return 0;
	    
}

BOOL Sync(DWORD *pdwStart, WORD wmsTime)
{
	TIMERINFO ti ={ sizeof(TIMERINFO) };
	do
	{
		if (MyYield()) return TRUE;
		TimerCount(&ti);
	} while (ti.dwmsSinceStart-*pdwStart<wmsTime);
	*pdwStart=ti.dwmsSinceStart;
	return FALSE;
}