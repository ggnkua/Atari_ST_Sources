/* bifurkationen C Objekt f�r GFA Basic HT '97 */

#include <windows.h>
#include <gfa.h>
#include <conio.h>
#include <stdio.h>
/*#include <math.h>*/

GPROC P_PUNKT(HWND hdlw, HDC dc, int gmx, int gmy, int color);
GFUNCN P_WHATSON(HWND hdlw, HDC dc);
HWND hdlw;
HDC dc;

main(){}

void FAR PASCAL Bifurc(HWND hdlw, HDC dc, int getmaxx, int getmaxy, int mo)
{
	float r=.95,x,delta_r;
	int i,j, row, col, mx,my,r1;
	mx=getmaxx; my=getmaxy;
	/*for (j=0; j<1; j++);*/
	{
		delta_r = 0.005;
		if (mo == 1)
		{
			r = 3.55;
			delta_r = 0.0005;
		}
		for (col=0; col<mx; col++)
		{
			r1=P_WHATSON(hdlw,dc);
			if (r1==1)
				break;
			x = .5;
			r += delta_r;
			for (i=0; i<256; i++)
			{
				if (r1==1)
					break;
				x = r*x*(1-x);
				if ((x>1000000) || (x<-1000000))
					break;
/*  COMPUTATION FOR rx(1-x)  */

				row = my -(x*my);
/*  COMPUTATION FOR x(1-x)
				row = my -((x/r)*2*my);
*/
				if ((i>64) && (row<my) && (row>=0) &&
					(col>=0) && (col<mx))
				{
					P_PUNKT(hdlw,dc,col,row,i%8+1);
				}
			}
		}
	}
}