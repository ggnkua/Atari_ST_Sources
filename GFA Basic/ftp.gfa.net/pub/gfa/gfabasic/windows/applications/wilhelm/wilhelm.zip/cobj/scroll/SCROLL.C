/* Scroll Bmp Beispiel als C Objekt f�r GFA Basic HT '97
C Source nach Irene Bauder's scroll.c */

/* folgende generelle �nderungen (zumindest f�r Symantec 6.x):

	- Einbinden der gfa.h f�r alle F�lle
	- von GFA Basic aufzurufende Funktion(en) wird far Pascal ..()
	- In Message Funktionen mu� (bei Symantec mit der dos Lib-
	  rary ?) aus WORD wParam unsigned wParam werden, zumindest
	  im Prototyp !?

	- die Funktion main als dos �berbleibsel hat keine Funktion
	  au�er der, da� man sie f�r die dos Library angeben mu�, sonst
	  bem�ngelt der Linker automatisch ihr Fehlen, weil sie im dos
	  Objekt (!) drin steht - ganz recht, es ist ein "dos Objekt",
	  wie man es ja auch vom WinIo System (A. Schulman) her kennt -
	  GFA Basic kann alternativ zum WinIo System verwendet werden !!
	
	- Funktionen, Prozeduren, Variablen etc. aus GFA Basic, die
	  von hier aus angesprochen werden sollen (jetzt nur als Bei-
	  spiel) m�ssen die Deklarationsform aus gfa.h einhalten, wie
	  PROCEDURE info(hdlw&) ist GPROC P_INFO(HWND); u.s.w. siehe  
	  auch im Compiler Buch Anhang..

	- Comilieren + Linken :
	- 1. GFA Basic Obj - 
	  gen -0 -1 -2 -a scroll.gfw  liefert ~gfa.obj // small, word, 286
	- 2. C Obj - 
	  sc -a2 -ms -2 -c scroll.c liefert scroll.obj // small, word, 286
	- meistens kann man mit der GFA Basic Compiler IDE und ~gfa.def
	  compilieren - linken, sonst geht's �ber die Komandozeile ganz
	  korrekt (hier mit scroll.def):
	- 3. linken -
	  gfalnk /REO/A:16/NOL/PACKC:38000/F/DEL/RC:scroll.res ~gfa.obj+
	  scroll.obj,scroll.exe,,glib.lib+sds.lib,scroll.def
	- die Ressource m�ssen Sie irgendwie selbst basteln, beim BMP Bei-
	  spiel hier lie�e sich das Bild auch von der Platte weg aufrufen

	- fertig ! */

/* so oder so �hnlich geht's immer - viel Spa� bei Ihren C Objekt 
   Expeditionen  ! N.K.  */


#include <windows.h>
#include <gfa.h>

#if _MSC_VER >= 700
#pragma warning (disable:4028)
#endif

#ifndef max
	#define max(a,b)  ((a) > (b) ? (a) : (b))
#endif
#ifndef min
	#define min(a,b)  ((a) < (b) ? (a) : (b))
#endif

long FAR PASCAL ScrollWndProc (HWND, unsigned, unsigned, LONG) ;
GPROC P_INFO(HWND); /* info aus GFA Basic - re. Maustaste */
main(){/* nix f�r dos*/}

int far PASCAL WinMain (hInstance, hPrevInstance, lpszCmdLine, nCmdShow)
	HANDLE	 hInstance, hPrevInstance ;
	LPSTR lpszCmdLine ;
	int   nCmdShow ;
{
HWND  hWnd ;
MSG   msg ;
WNDCLASS wndclass ;

	if (!hPrevInstance)
	{
	wndclass.style	  =  CS_HREDRAW | CS_VREDRAW ;
	wndclass.lpfnWndProc =	ScrollWndProc;
	wndclass.cbClsExtra  =	0 ;
	wndclass.cbWndExtra  =	0 ;
	wndclass.hInstance	=  hInstance ;
	wndclass.hIcon	  =  LoadIcon (NULL, IDI_APPLICATION) ;
	wndclass.hCursor     =	LoadCursor (NULL, IDC_ARROW) ;
	wndclass.hbrBackground	=  GetStockObject (WHITE_BRUSH) ;
	wndclass.lpszMenuName	=  NULL ;
	wndclass.lpszClassName	=  "Scroll" ;

	if (!RegisterClass (&wndclass))
		return FALSE ;
	}

	hWnd = CreateWindow ("Scroll","C Bitmap Scroll Example in GFA Basic",
		 WS_OVERLAPPEDWINDOW | WS_VSCROLL | WS_HSCROLL,
		CW_USEDEFAULT, 0,
		CW_USEDEFAULT, 0,
		NULL, NULL, hInstance, NULL) ;

	ShowWindow (hWnd, nCmdShow) ;
	UpdateWindow (hWnd) ;

	while (GetMessage (&msg, NULL, 0, 0))
	{
		TranslateMessage (&msg) ;
		DispatchMessage (&msg) ;
	}
	return msg.wParam ;
}

long FAR PASCAL ScrollWndProc (hWnd, message, wParam, lParam)
	HWND  hWnd ;
	unsigned message ;
	WORD  wParam ; /* hier geht WORD ? */
	LONG  lParam ;
{
	HANDLE	 hInst;
	static short   xClient, yClient;
	static short   sVertPos, sVertOld, sHorzPos, sHorzOld;
	static BITMAP  bm;
	static HBITMAP hBitmap, hBitOld;
	static short   sMaxHeight, sMaxWidth;
	HDC   hDC, hMemDC;
	PAINTSTRUCT ps;

	switch (message)
	{
		case WM_CREATE:
			hInst = GetWindowWord(hWnd, GWW_HINSTANCE);
			hBitmap = LoadBitmap(hInst, "Chess");
			GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&bm);
			sMaxHeight = bm.bmHeight ;
			sMaxWidth = bm.bmWidth;

			SetScrollRange (hWnd, SB_VERT, 0, sMaxHeight, FALSE) ;
			SetScrollPos   (hWnd, SB_VERT, sVertPos, TRUE) ;
			SetScrollRange (hWnd, SB_HORZ, 0, sMaxWidth, FALSE) ;
			SetScrollPos   (hWnd, SB_HORZ, sHorzPos, TRUE) ;
			break ;

		case WM_SIZE:
			yClient = HIWORD (lParam) ;
			xClient = LOWORD (lParam) ;
			break ;

		case WM_VSCROLL:
			sVertOld = sVertPos;

			switch (wParam)
			{
				case SB_LINEUP:
					sVertPos -= 1 ;
					break ;

				case SB_LINEDOWN:
					sVertPos += 1 ;
					break ;

				case SB_PAGEUP:
					sVertPos -=  yClient ;
					break ;

				case SB_PAGEDOWN:
					sVertPos += yClient ;
					break ;

				case SB_TOP:
					sVertPos = 0;
					break;

				case SB_BOTTOM:
					sVertPos = sMaxHeight;
					break;

				case SB_THUMBTRACK:
					sVertPos = LOWORD(lParam);
					break ;

				default:
					break ;
			}
			sVertPos = max (0, min (sVertPos, sMaxHeight)) ;

			if (sVertPos != GetScrollPos (hWnd, SB_VERT))
			{
				ScrollWindow (hWnd, 0,sVertOld-sVertPos, NULL, NULL);
				UpdateWindow(hWnd);
				SetScrollPos (hWnd, SB_VERT, sVertPos, TRUE) ;
			}
			break ;

		case WM_HSCROLL:
			sHorzOld = sHorzPos;

			switch (wParam)
			{
				case SB_LINEUP:
					sHorzPos -= 1 ;
					break ;

				case SB_LINEDOWN:
					sHorzPos += 1 ;
					break ;

				case SB_PAGEUP:
					sHorzPos -= xClient ;
					 break ;

				case SB_PAGEDOWN:
					sHorzPos += xClient ;
					 break ;

				case SB_THUMBPOSITION:
					sHorzPos = LOWORD(lParam);
					break ;

				default:
					break;
			 }

			sHorzPos = max (0, min (sHorzPos, sMaxWidth)) ;

			if (sHorzPos != GetScrollPos (hWnd, SB_HORZ))
			{
				ScrollWindow (hWnd, sHorzOld-sHorzPos,0, NULL, NULL);
				UpdateWindow(hWnd);
				SetScrollPos (hWnd, SB_HORZ, sHorzPos, TRUE) ;
			}

			break ;

		case WM_KEYDOWN:
			switch (wParam)
			{
				case VK_UP:
					SendMessage (hWnd, WM_VSCROLL, SB_LINEUP, 0L);
					break;

				case VK_DOWN:
					SendMessage (hWnd, WM_VSCROLL, SB_LINEDOWN, 0L);
					break;

				case VK_PRIOR:
					SendMessage (hWnd, WM_VSCROLL, SB_PAGEUP, 0L);
					break;

				case VK_NEXT:
					 SendMessage (hWnd, WM_VSCROLL, SB_PAGEDOWN, 0L);
					break;

				case VK_LEFT:
					SendMessage (hWnd, WM_HSCROLL, SB_LINEUP, 0L);
					break;

				case VK_RIGHT:
					SendMessage (hWnd, WM_HSCROLL, SB_LINEDOWN, 0L);
					break;

				case VK_HOME:
					SendMessage (hWnd, WM_VSCROLL, SB_TOP, 0L);
					break;

				case VK_END:
					SendMessage (hWnd, WM_VSCROLL, SB_BOTTOM,0L);
					break;

				default:
					break;
			}
			break;
		case WM_RBUTTONDOWN:
			P_INFO(hWnd);
			break;
		case WM_PAINT:
			hDC = BeginPaint (hWnd, &ps) ;
			hMemDC = CreateCompatibleDC( hDC );
			hBitOld = SelectObject(hMemDC,hBitmap);
			BitBlt(hDC, ps.rcPaint.left, ps.rcPaint.top,
				ps.rcPaint.right,ps.rcPaint.bottom, hMemDC,
				sHorzPos+ps.rcPaint.left, sVertPos+ps.rcPaint.top, SRCCOPY);
			SelectObject(hMemDC,hBitOld);
			DeleteDC(hMemDC);
			EndPaint (hWnd, &ps) ;
			break ;

		case WM_DESTROY:
			PostQuitMessage (0) ;
			break ;

		default:
			return DefWindowProc (hWnd, message, wParam, lParam) ;
	}
	return 0L ;
}

