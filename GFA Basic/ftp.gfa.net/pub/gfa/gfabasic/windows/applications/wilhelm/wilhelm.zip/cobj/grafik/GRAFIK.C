/****************************************************************************
 GRAFIK.C modifiziert f�r die Einbindung in GFA Basic mit DLL 's HT '97
 ========
						    - word small 286 -	
 zum Objekt f�r GFA Basic compilieren (Symantec): sc -a2 -ms -c -2 grafik.c

 Dieses Programm verfolgt den Zweck, einige Grundlagen der Programmierung
 von Grafik mit Hilfe der GDI (Graphics Device Interface) SDK-Funktionen
 von Windows zu demonstrieren.

 Diese Version zeigt zus�tzlich anhand dieses C Grafik Beispiels eine Technik
 auf, mit deren Hilfe Ressourcen und ganze C Listings lediglich mit einem 
 C Compiler, der die Windows.h lesen kann + einer Dos Lib (!) in GFA Basic ein-
 gebunden werden k�nnen...sogar eine Pascal / GFA Basic Ressource DLL ist dabei ! 

 Schwerpunkte: Das GDI-Koordinatensystem
               Mapping-Modi
               Brushes und Pens
               Farbeinstellung
 ***************************************************************************/

/* -------------------------< Include-Dateien >--------------------------- */

#include <windows.h>
#include <gfa.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <io.h>

#include "grafik.h"

/* -----------------------------< Defines >------------------------------- */

#define MAXNAMELENGTH 30                    // Max. L�nge des Applikationsnamens
#define MAXBRUSHES    5                     // Anzahl verwendeter Brushes
#define MAXPENS       5                     // Anzahl verwendeter Pens

/* ------------------------< Globale Variablen >-------------------------- */

HANDLE       hInst;                         // Instanz der Applikation
HWND         hwMain;                        // Hauptfenster
char         szApplName[MAXNAMELENGTH];     // Applikationsname
FARPROC      lpfnModal,                     // F�r modale Dialogboxen
             lpfnModeless;                  // F�r nichtmodale Dialogboxen
int          nCurMapMode,                   // Aktueller Mapping-Modus
             nCurWindowXExtent,             // Aktuelle Fensterbreite 
             nCurWindowYExtent,             // Aktuelle Fensterh�he
             nCurViewXExtent,               // Aktuelle Viewportbreite
             nCurViewYExtent,               // Aktuelle Viewporth�he
             nCurFgColor,                   // Aktuelle Vordergrundfarbe
             nCurBgColor,                   // Aktuelle Hintergrundfarbe
             nCurYDirection = -1;           // Aktuelle Ausrichtung der y-Achse
POINT        ptCurWindowOrg,                // Aktueller Fenster-Ursprung
             ptCurViewOrg;                  // Aktueller Viewport-Ursprung
HBRUSH       ahBrushes[MAXBRUSHES];         // Feld mit den verwendeten Brushes
HPEN         ahPens[MAXPENS];               // Feld mit den verwendeten Pens
POINT        aptVertTriangle[3] =           // Pfeil an der y-Achse
                  { { -15, 180 },
                    {   0, 200 },
                    {  15, 180 } },
             aptHorzTriangle[3] =           // Pfeil an der x-Achse
                  { { 180,  15 },
                    { 200,   0 },
                    { 180, -15 } },
             aptVertTmTriangle[3] =         // Pfeil an der y-Achse (MM_TEXT)
                  { { -15, -180 },
                    {   0, -200 },
                    {  15, -180 } },
             aptHorzTmTriangle[3] =         // Pfeil an der x-Achse (MM_TEXT)
                  { { 180,  -15 },
                    { 200,   0  },
                    { 180,   15 } },
             aptTriangle[4] =
                  { {  80, -30  },
                    {  130,-130 },
                    {  30, -130 },
                    {  80, -30  } },
             aptTmTriangle[4] =
                  { {  80,  30  },
                    {  130, 130 },
                    {  30,  130 },
                    {  80,  30  } };
// Texte f�r die Fenstertitelleiste
char * aszMapModes[8] = { "MM_TEXT",      "MM_LOMETRIC",  "MM_HIMETRIC",
                          "MM_LOENGLISH", "MM_HIENGLISH", "MM_TWIPS",
                          "MM_ISOTROPIC", "MM_ANISOTROPIC" };

/* -----------------------< Funktions-Prototypen>------------------------- */

LONG FAR PASCAL MainWndProc (HWND, unsigned, unsigned, LONG);
BOOL FAR PASCAL MdfAboutProc (HWND, unsigned, unsigned, LONG); //siehe unten
void PaintGrafik (HWND);
GPROC P_PASCDIALOG(HWND);	/* mit mdfaboutproc1() aus GFA Basic */
GPROC P_GFADIALOG(HWND);	/* dto. */	
main(){/*wir geben nix f�r dos*/} /* f�r die sds.lib und ihr _main */

/****************************************************************************
 W i n M a i n ()
 ================

 Die WinMain Funktion ist die Hauptfunktion jedes Windows Programms. Sie ist
 das Windows �quivalent zur main() Funktion normaler C-Programme und stellt
 den Einstiegspunkt in den Ablauf einer Applikation dar.

 Parameter:

   HANDLE hInstance:     Aktuelle Instanz der Applikation.
   HANDLE hPrevInstance: Vorhergehende Instanz der Applikation.
                         NULL, wenn die aktuelle Instanz die erste
                         Instanz ist.
   LPSTR  lpszCmdLine:   Long Zeiger auf die Zeichenkette, die hinter dem
                         Programmnamen beim Programmaufruf eingegeben wurde.
   int    nCmdShow:      Parameter, der festlegt, wie das Hauptfenster der
                         Applikation beim Programmstart erscheinen soll.

 R�ckgabewert:

   int:                  Der wParam Parameter der zuletzt empfangenen Meldung.
 ***************************************************************************/
/* WinMain wird zur Far Proc f�r GFA Basic ! */

int far pascal WinMain (hInstance,  hPrevInstance,
                    lpszCmdLine, nCmdShow)
HANDLE  hInstance, hPrevInstance;
LPSTR   lpszCmdLine;
int             nCmdShow;
{
  MSG   msg;                      // Variable zur Aufnahme von Nachrichten
  
  if (!hPrevInstance)             // Initialisierung der ersten Instanz
  {
     
  	WNDCLASS MainWndClass;                    // Fensterklasse des Hauptfensters
	 	  	 
  	// Festlegen der Fensterklassen-Informationen
  	MainWndClass.lpszClassName = "Grafik";                  // Fensterklasse
  	MainWndClass.hInstance     = hInstance;                   // Instanz
  	MainWndClass.lpfnWndProc   = MainWndProc;                 // Fensterfunktion
  	MainWndClass.style         = CS_HREDRAW | CS_VREDRAW;
  	MainWndClass.lpszMenuName  = NULL;  // mit geg. hInstance keine Anmeldung n�tig  
  	MainWndClass.hCursor       = LoadCursor(NULL, IDC_ARROW); // Pfeil-Cursor
  	MainWndClass.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDDIALOGICON));
  	MainWndClass.hbrBackground = GetStockObject(WHITE_BRUSH); // Weisser Hintergrund
  	MainWndClass.cbClsExtra    = 0;                           // Keine Extra-Bytes
  	MainWndClass.cbWndExtra    = 0;                           // Keine Extra-Bytes

  	// Registrieren der Fensterklasse "Grafik"
  	if (!RegisterClass(&MainWndClass))
      			return NULL;
	
    // Erzeugen von Brushes
    ahBrushes[0] = CreateSolidBrush(RGB(255, 0, 0));           // Rot
    ahBrushes[1] = CreateSolidBrush(RGB(0, 255, 0));           // Gr�n
    ahBrushes[2] = CreateSolidBrush(RGB(0, 0, 255));           // Blau
    ahBrushes[3] = CreateSolidBrush(RGB(255, 255, 255));       // Wei�
    ahBrushes[4] = CreateSolidBrush(RGB(0, 0, 0));             // Schwarz

    // Erzeugen von Pens
    ahPens[0]    = CreatePen(PS_SOLID, 1, RGB(255, 0, 0));     // Rot
    ahPens[1]    = CreatePen(PS_SOLID, 1, RGB(0, 255, 0));     // Gr�n
    ahPens[2]    = CreatePen(PS_SOLID, 1, RGB(0, 0, 255));     // Blau
    ahPens[3]    = CreatePen(PS_SOLID, 1, RGB(255, 255, 255)); // Wei�
    ahPens[4]    = CreatePen(PS_SOLID, 1, RGB(0, 0, 0));       // Schwarz
  }
  else                            // Weitere Instanzen werden nicht zugelassen
  {
    return NULL;
  }

  hInst  = hInstance;                           // �bergabe an die globale
                                                // Instanz-Variable

  hwMain = CreateWindow("Grafik",             // Name der Fensterklasse
                        "Grafik",             // Titel des Hauptfensters
                        WS_OVERLAPPEDWINDOW |   // �berlappend
                        WS_VSCROLL|WS_VISIBLE,  // mit Bildlaufleiste
                        CW_USEDEFAULT,          // x-Position (Default)
                        CW_USEDEFAULT,          // y-Position (Default)
                        CW_USEDEFAULT,          // Fensterbreite (Default)
                        CW_USEDEFAULT,          // Fensterh�he (Default)
                        NULL,                   // Kein Vaterfenster
                        LoadMenu(hInstance, "MAINMENU"),
                        hInstance,              // Instanz der Applikation
                        NULL);                  // Keine Extra-Parameter

   if (!hwMain) {MessageBeep(0);
     return NULL;}

  /* ---------------------< Hauptfenster anzeigen >----------------------- */

   ShowWindow(hwMain, nCmdShow);                // Fenster sichtbar machen
   UpdateWindow(hwMain);                        // Fenster aktualisieren

  /* ----------------------< Nachrichtenschleife >------------------------ */

  while (GetMessage(&msg, NULL, 0, 0))          // Nachrichten-Polling
  {
      TranslateMessage(&msg);                   // Nachricht �bersetzen
      DispatchMessage(&msg);                    // Nachricht verteilen
  }
  return (msg.wParam);                          // Applikation beenden
} // WinMain


/****************************************************************************
 M a i n W n d P r o c ()
 ========================

 Diese Funktion ist die Fensterfunktion des Hauptfensters.
 Sie bearbeitet alle Nachrichten, die an dieses Fenster gesendet werden.

 Parameter:

   HWND     hWnd:     Fensterhandle.
   unsigned msg:      Typ der Nachricht.
   (WORD)unsigned     wP:       Nachrichtenabh�ngiger 16 Bit Wert
   LONG     lP:       Nachrichtenabh�ngiger 32 Bit Wert

 R�ckgabewert:

   LONG               0L, wenn die Fensterfunktion die �bergebene Nachricht
                      bearbeitet hat, sonst der R�ckgabewert der Default-
                      Fensterfunktion DefWindowProc.
 ***************************************************************************/

LONG FAR PASCAL MainWndProc (HWND hWnd, unsigned msg, unsigned wP, LONG lP)
{
   static  HMENU hMainMenu;      // Handla auf das Hauptmen�
   static  HMENU hColorMenu;     // Handle auf das Farben-Men�
   int     nResult;              // R�ckgabewert der DialogBox Funktion
   WORD    i;

   switch (msg)
   {
     case WM_CREATE:             // Vor Erscheinen des Fensters
       // Handle auf das Hauptmen� holen
       hMainMenu = GetMenu(hWnd);

       // Handle auf das "Farben"-Untermen� holen
       hColorMenu = GetSubMenu(hMainMenu, 2);

       // Initialisierung von Men�punkten
       CheckMenuItem(hMainMenu, MI_MM_TEXT, MF_CHECKED);

       // Initialisierung Vordergrundfarbe schwarz, Hintergrundfarbe wei�
       CheckMenuItem(GetSubMenu(hColorMenu, 0), MI_FG_BLACK, MF_CHECKED);
       CheckMenuItem(GetSubMenu(hColorMenu, 1), MI_BG_WHITE, MF_CHECKED);

       // Initialisierung wichtiger GDI-Parameter
       nCurMapMode       = MM_TEXT;            // Mapping-Modus
       nCurWindowXExtent = 1000;               // Fenster-Abmessungen
       nCurWindowYExtent = 1000;            
       nCurFgColor       = MI_FG_BLACK;        // Vordergrundfarbe
       nCurBgColor       = MI_BG_WHITE;        // Hintergrundfarbe
       break;

     case WM_DESTROY:
       // Freigabe der allokierten GDI-Ressourcen
       for (i=0; i<MAXBRUSHES; i++)
         DeleteObject(ahBrushes[i]);
       for (i=0; i<MAXPENS; i++)
         DeleteObject(ahPens[i]);

       // Wenn das Fenster zerst�rt wird, WM_QUIT Nachricht senden
       PostQuitMessage(0);       
       break;

     case WM_RBUTTONDOWN:        // Rechte Maustaste gedr�ckt
       // Orientierung der y-Achse umkehren
       nCurYDirection = -nCurYDirection;

       // WM_PAINT Nachricht erzeugen
       InvalidateRect(hWnd, NULL, TRUE);
       break;

     case WM_COMMAND:            // Nachrichten von der Men�leiste
       switch (wP)
       {
         case MI_QUIT:           // Programm beenden
           PostMessage(hwMain, WM_SYSCOMMAND, SC_CLOSE, 0L);
           break;

         case MI_ABOUT:          // Aufruf der "Info �ber Grafik" Dialogbox
           lpfnModal = MakeProcInstance(MdfAboutProc, hInst);
           nResult = DialogBox(hInst, "ABOUTDLG", hwMain, lpfnModal);
           FreeProcInstance(lpfnModal);
           break;
	 case MI_PASC:		/* Pascal DLL Ressource, wenn's klappt*/
	   P_PASCDIALOG(hwMain);
	   break;
	 case MI_GFA:		/* GFA  DLL Ressource, und hat geklappt */
	   P_GFADIALOG(hwMain);
	   break;

         case MI_MM_TEXT:        // Ver�nderung des Mapping-Modus
         case MI_MM_ANISOTROPIC:
         case MI_MM_ISOTROPIC:
         case MI_MM_LOMETRIC:
         case MI_MM_HIMETRIC:
         case MI_MM_LOENGLISH:
         case MI_MM_HIENGLISH:
         case MI_MM_TWIPS:
           // Umwandlung in einen Define-Wert aus WINDOWS.H
           nCurMapMode = wP-MI_MM_TEXT+1;

           for (i=MI_MM_TEXT; i<=MI_MM_ANISOTROPIC; i++)
           {
             if (i == wP)        // Selektierten Eintrag checken
               CheckMenuItem(hMainMenu, i, MF_CHECKED);
             else                // Sonstige Eintrage nicht checken
               CheckMenuItem(hMainMenu, i, MF_UNCHECKED);
           }
           // Erzeugen einer WM_PAINT Nachricht
           InvalidateRect(hWnd, NULL, TRUE);
           break;

         case MI_FG_RED:         // Ver�nderung der Vordergrundfarbe
         case MI_FG_GREEN:
         case MI_FG_BLUE:
         case MI_FG_WHITE:
         case MI_FG_BLACK:
           nCurFgColor = wP-MI_FG_RED;

           for (i=MI_FG_RED; i<=MI_FG_BLACK; i++)
           {
             if (i == wP)        // Selektierten Eintrag checken
               CheckMenuItem(GetSubMenu(hColorMenu, 0), i, MF_CHECKED);
             else                // Sonstige Eintrage nicht checken
               CheckMenuItem(GetSubMenu(hColorMenu, 0), i, MF_UNCHECKED);
           }
           // Erzeugen einer WM_PAINT Nachricht
           InvalidateRect(hWnd, NULL, TRUE);
           break;

         case MI_BG_RED:         // Ver�nderung der Hintergrundfarbe
         case MI_BG_GREEN:
         case MI_BG_BLUE:
         case MI_BG_WHITE:
         case MI_BG_BLACK:
           nCurBgColor = wP-MI_BG_RED;

           for (i=MI_BG_RED; i<=MI_BG_BLACK; i++)
           {
             if (i == wP)        // Selektierten Eintrag checken
               CheckMenuItem(GetSubMenu(hColorMenu, 1), i, MF_CHECKED);
             else                // Sonstige Eintrage nicht checken
               CheckMenuItem(GetSubMenu(hColorMenu, 1), i, MF_UNCHECKED);
           }
           // Erzeugen einer WM_PAINT Nachricht
           InvalidateRect(hWnd, NULL, TRUE);
           break;

	  default:
	    break;
       }
       break;

     case WM_PAINT:              // Update der Client Area erforderlich
       PaintGrafik(hWnd);
       break;

     default: // Sonstige Nachrichten an Default-Fensterfunktion weiterleiten
       return (DefWindowProc(hWnd, msg, wP, lP));
       break;
   }
   return 0L;
} // MainWndProc

/****************************************************************************
 M d f A b o u t P r o c ()
 ==========================

 Diese Funktion bearbeitet die Nachrichten der "Info �ber Grafik" Dialogbox.
 Die Funktion ist als Call Back Procedure in Gfa Basic einbaubar - einfach
 von hier in den Interpreter �bertragen - umgeschrieben ! Sie kann aber auch
 hier aktiviert und in GFA Basic gestrichen werden - ganz egal - siehe dort,
 es ist sowieso das gleiche.

 momentane Einstellung: von hier aus f�r die C Info Box.

 Parameter:

   HWND     hDlg:     Handle der Dialogbox.
   unsigned msg:      Typ der Nachricht.
   (WORD)unsigned     wP:       Nachrichtenabh�ngiger 16 Bit Wert
   LONG     lP:       Nachrichtenabh�ngiger 32 Bit Wert

 R�ckgabewert:

   BOOL               TRUE, wenn die Dialogfunktion die �bergebene Nachricht
                      bearbeitet hat, sonst FALSE.
 ***************************************************************************/

BOOL FAR PASCAL MdfAboutProc (HWND hDlg, unsigned msg, unsigned wP, LONG lP)
{
  switch (msg)
  {
    case WM_INITDIALOG:        // Nachricht vor der Darstellung der Dialogbox
      return TRUE;             // Keine Initialisierungen durchzuf�hren
      break;

    case WM_COMMAND:           // Nachricht von Steuerungen der Dialogbox
      switch (wP)
      {
        case IDOK:             // Bet�tigung der "Ok" Schaltfl�che
          EndDialog(hDlg, TRUE);
          return TRUE;
          break;

        default:               // Sonstige Nachrichten
          return FALSE;
          break;
      }
      break;
    case WM_CLOSE:   // N.K.: einfach k�rzer, vielleicht nicht das hohe C ?
	EndDialog(hDlg, TRUE);
	return TRUE;
	break;
	
   /* case WM_SYSCOMMAND:        // Nachricht vom Systemmen� der Dialogbox
      switch (wP)
      {
        // ALT+F4, Doppelklick auf das Systemmen� oder Men�punkt "Schlie�en"
        // des Systemmen�s vom Benutzer angew�hlt

        case SC_CLOSE:
          EndDialog(hDlg, TRUE);
          return TRUE;
          break;

        default:               // Sonstige Systemmen� Nachrichten
          return FALSE;
          break;
      }
      break;*/

    default:                   // Sonstige Nachrichten
        return FALSE;
        break;
  }
}

/****************************************************************************
 P a i n t G r a f i k ()
 ========================

 Diese Funktion ist f�r das Neuzeichnen der Client Area des Hauptfensters
 zust�ndig.

 Parameter:

   HWND    hWnd:    Fensterhandle.

 R�ckgabewert:      Keiner.
 ***************************************************************************/

 void PaintGrafik (HWND hWnd)
 {
   PAINTSTRUCT ps;              // Informationen ueber die Client Area
   HDC         hDC;             // Handle auf Display Context
   RECT        rClientRect;     // Client-Area Rechteck
   char        szTitleBar[80];  // Text der Titelleiste des Hauptfensters

   hDC = BeginPaint(hWnd, &ps); // Display Context des Hauptfensters holen

   // Dimensionen der Client-Area feststellen
   GetClientRect(hWnd, &rClientRect);

   // Aktuellen Mapping-Modus einstellen
   SetMapMode (hDC, nCurMapMode);

   // Mapping-Modus in der Titelleiste des Hauptfensters anzeigen
   wsprintf(szTitleBar, "%s - %s Mapping-Modus",
                        ("Grafik", (LPSTR)aszMapModes[nCurMapMode-1]));
   SetWindowText(hWnd, (LPSTR)szTitleBar);

   nCurViewXExtent   = rClientRect.right;    // Dimensionen des Viewports
   nCurViewYExtent   = rClientRect.bottom;
   ptCurViewOrg.x    = nCurViewXExtent/2;    // Viewport-Ursprung setzen
   ptCurViewOrg.y    = nCurViewYExtent/2; 
   ptCurWindowOrg.x  = 0;                    // Fenster-Ursprung setzen
   ptCurWindowOrg.y  = 0;

   // Festlegen des Viewport-Ursprungs
   SetViewportOrg(hDC, ptCurViewOrg.x, ptCurViewOrg.y);

   // Festlegen des Fenster-Ursprungs
   SetWindowOrg(hDC, ptCurWindowOrg.x, ptCurWindowOrg.y);

   if ((nCurMapMode == MM_ISOTROPIC) || (nCurMapMode == MM_ANISOTROPIC))
   {
     // Festlegen der Fenster-Dimensionen
     SetWindowExt(hDC, nCurWindowXExtent, nCurWindowYExtent);

     // Festlegen der Viewport-Dimensionen
     SetViewportExt(hDC, nCurViewXExtent, nCurYDirection*nCurViewYExtent);
   }

   // Setzen der Hintergrundfarbe
   SelectObject(hDC, ahBrushes[nCurBgColor]);

   // Setzen der Vordergrundfarbe
   SelectObject(hDC, ahPens[nCurFgColor]);

   // Zeichnen des Koordinatenkreuzes und der Grafik-Elemente
   if (nCurMapMode != MM_TEXT)
   {
     Ellipse(hDC, -200, 200, 200, -200);          // Kreis
     MoveTo(hDC, -200, 0);
     LineTo(hDC, 200, 0);                         // x-Achse
     MoveTo(hDC, 0, 200);
     LineTo(hDC, 0, -200);                        // y-Achse

     // Quadrat im 1. Quadrant
     Rectangle(hDC, 30, 130, 130, 30);
     // Kreis im 2. Quadrant
     Arc(hDC, -130, 130, -30, 30, -30, 30, -30, 30);
     // Quadrat mit abgerundeten Ecken im 3. Quadrant
     RoundRect(hDC, -130, -30, -30, -130, 20, 20);                 
     // Dreieck im 4. Quadrant
     Polyline(hDC, (LPPOINT)aptTriangle, 4);

     Polygon(hDC, (LPPOINT)aptVertTriangle, 3);   // Pfeil am Ende der y-Achse
     Polygon(hDC, (LPPOINT)aptHorzTriangle, 3);   // Pfeil am Ende der x-Achse
   }
   else // Im MM_TEXT Modus mit -1 multiplizierte y-Werte verwenden
   {
     Ellipse(hDC, -200, -200, 200, 200);
     MoveTo(hDC, -200, 0);
     LineTo(hDC, 200, 0);
     MoveTo(hDC, 0, -200);
     LineTo(hDC, 0, 200);
     Rectangle(hDC, 30, -130, 130, -30);
     Arc(hDC, -130, -130, -30, -30, -30, -30, -30, -30);
     RoundRect(hDC, -130, 30, -30, 130, 20, 20);
     Polyline(hDC, (LPPOINT)aptTmTriangle, 4);
     Polygon(hDC, (LPPOINT)aptVertTmTriangle, 3);
     Polygon(hDC, (LPPOINT)aptHorzTmTriangle, 3);
   }

   EndPaint(hWnd, &ps);         // Display Context wieder freigeben
 } // PaintGrafik


