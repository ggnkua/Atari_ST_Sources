/* M�lleimer f�r Windows mit Symantec 6.1 C Objekt f�r GFA Basic HT '97 */
/* modifizerte Idee von Gerhard Schild */
/* compilieren: sc -a2 -ms -c -2 trash.c */
/* aus WORD msg,wp wird bei Symantec 6.1 unsigned !(?) */

#define TITLE "Dustbin"
#define INFRONT 1
#include <windows.h>
#include <gfa.h>

void FAR PASCAL DragAcceptFiles(HWND, BOOL);
WORD FAR PASCAL DragQueryFile(HANDLE, int, LPSTR, WORD);
void FAR PASCAL DragFinish(HANDLE);
main(){/* nix f�r dos */}

#ifndef WINVER
WINDOWS 3.1:
#define WM_DROPFILES 0x0223
#define WS_EX_ACCEPTFILES 0x10L
#define WS_EX_TOPMOST   0x08L
#endif

long FAR PASCAL WndProc(HWND hwnd, unsigned msg, unsigned wp, LONG lp)
{
        char file[128];
        OFSTRUCT of;
        int i;
        switch(msg)
        {
        case WM_DESTROY:
                PostQuitMessage(0);
                break;
        case WM_QUERYOPEN:
                return NULL;
        case WM_DROPFILES:
                for(i=0; DragQueryFile(wp, i, file, 128); i++)
                        OpenFile(file, &of, OF_DELETE);
                        DragFinish(wp);
                        return NULL;
        }
	return DefWindowProc(hwnd,msg,wp,lp);
}

int far PASCAL WinMain(HANDLE hInstance, 
        HANDLE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
        static WNDCLASS wc;
        MSG msg;
        if (!hPrevInstance)
        {
                wc.lpfnWndProc=WndProc;
                wc.hInstance=hInstance;
                wc.hIcon=LoadIcon(hInstance, "#1");
                wc.lpszClassName=TITLE;
                RegisterClass(&wc);
        }
        CreateWindowEx(WS_EX_ACCEPTFILES|WS_EX_TOPMOST*INFRONT, TITLE, 
                "Dustbin",WS_ICONIC|WS_VISIBLE|WS_SYSMENU,
                0,0,0,0,NULL,NULL,hInstance,NULL);
                while(GetMessage(&msg,0,0,0))
                DispatchMessage(&msg);
                return msg.wParam;
}
