/*          ���������������������������������������������������������������ͻ
            �                                                               �
            �                                                               �
	    �     sedona = PROGRAM TO GENERATE OAK CREEK CANYON LANDSCAPE   �
	    �     modified to Symantec 6.1 Obj for GFA Basic HT '95 - 97    �
	    ���������������������������������������������������������������ͼ
*/
#include <windows.h>
#include <gfa.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <conio.h>

void cactus (int x1, int y_one, int scale, int level, int color1, int color2);
void fillTriangle (int x1, int y_one, int x2, int y2, int x3, int y3,
	int color);
float gauss(void);
void gen_quad (int x1, int y_one, int x2, int y2, int x3, int y3, int x4,
	int y4, int level, int color1, int color2);
void generate(int x1, int y_one, int x2, int y2, int x3, int y3, int level,
	int color1,int color2);
void midpoint();
void node(int x1, int y_one, int x2, int y2, int x3, int y3, int x4,
	int y4, int x5, int y5, int x6, int y6, int level,
	int color1, int color2);
void plot_triangle(int x1, int y_one, int x2, int y2, int x3, int y3,
	int color1,int color2);
float random_no (unsigned int seed,float limit_start, float limit_end);
void sort(int index, int x_coord[], int y_coord[]);

GVWORD W_r;
GPROC P_WHATSON();               /* Vorteile von GFA Basic n�tzen...*/
GPROC P_PUNKT(int j,int i, int color);
GPROC P_LINIE( int x1, int y1, int x2 , int y2, int color);

int i,j;
int y_max = 280;
int level[26] = {3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4};
int x1[26] = {-330,-90,-90,120,120,120,  -160,-120,-120,-80,-80,-50,-50,-50,
	80,104,104,128,128,152,152,200};
int y_one[26] = {-110,-110,-110,-110,-110,-110, -10,-10,-10,-10,-10,-10,-10,-10,
	50,50,50,50,50,50,50,50};
int x2[26] = {-160,-160,0,0,80,200,  -160,-160,-120,-120,-80,-80,-50,0,
	100,100,104,104,128,128,152,152};
int y2[26] = {0,0,0,0,50,50,  220,220,190,190,230,230,100,180,
	180,180,200,205,215,215,160,160};
int x3[26] = {-90,0,120,80,200,340,  -120,-120,-80,-80,-50,-50,0,0,
	104,104,128,128,152,152,200,200};
int y3[26] = {-110,0,-110,50,50,-110,  -10,220,-10,200,-10,235,180,-10,
	50,200,50,210,50,220,50,140};

int xz,yz,xp,yp;
int color_value=2;
unsigned char PALETTE[16]={0,1,2,3,4,5,20,7,56,57,58,59,60,61,62,63};
float x,y;

main()
{
}

void far pascal sedona()
{
	for (i=0; i<22; i++)
		generate(x1[i],y_one[i],x2[i],y2[i],x3[i],y3[i],level[i],4,12);
	y_max = -100;
	for (i=-240; i<-75; i++)
		P_LINIE(-320,i,319,i, 11);
	gen_quad(-330,-260,-330,-130,60,-130,60,-260,4,6,14);
	gen_quad(-60,-260,-60,-130,330,-130,330,-260,4,6,14);
	y_max = 0;
	cactus(-110,-130,3,4,2,10);
	cactus(-200,-120,2,4,2,10);
	cactus(0,-160,4,4,2,10);
	cactus(210,-200,6,4,2,10);
}


void node(int x1, int y_one, int x2, int y2, int x3, int y3, int x4,int y4,
	int x5, int y5, int x6, int y6, int level,int color1, int color2)
{
	if (level == 0)
		return;
	generate (x1,y_one,x4,y4,x6,y6,level-1,color1,color2);
	generate (x6,y6,x5,y5,x3,y3,level-1,color1,color2);
	generate (x4,y4,x2,y2,x5,y5,level-1,color1,color2);
	generate (x4,y4,x5,y5,x6,y6,level-1,color1,color2);
}

void generate(int x1, int y_one, int x2, int y2, int x3, int y3, int level,
	int color1, int color2)
{
	int x4,x5,x6,y4,y5,y6,ax,bx,cx,ay,by,cy;

	x = x2 - x1;
	y = y2 - y_one;
	midpoint();
	x4 = x1 + xz -xp;
	y4 = y_one + yz - yp;
	ax = -xp;
	ay = -yp;
	x = x3-x1;
	y = y3-y_one;
	midpoint();
	x6 = x1 + xz;
	y6 = y_one + yz;
	cx = xp;
	cy = yp;
	x = x3-x2;
	y = y3-y2;
	midpoint();
	x5 = x2 + xz;
	y5 = y2 + yz;
	bx = -xp;
	by = -yp;

	if (level == 0)
	{
		plot_triangle(x1,y_one,x4,y4,x6,y6,color1,color2);
		plot_triangle(x6,y6,x5,y5,x3,y3,color1,color2);
		plot_triangle(x4,y4,x5,y5,x6,y6,color1,color2);
		plot_triangle(x4,y4,x2,y2,x5,y5,color1,color2);
	}
	else
	{
		plot_triangle(x1,y_one,x4+ax,y4+ay,x6+cx,y6+cy,color1,color2);
		plot_triangle(x6+cx,y6+cy,x5+bx,y5+by,x3,y3,color1,color2);
		plot_triangle(x4+ax,y4+ay,x5+bx,y5+by,x6+cx,y6+cy,color1,
			color2);
		plot_triangle(x4+ax,y4+ay,x2,y2,x5+bx,y5+by,color1,color2);
		node(x1,y_one,x2,y2,x3,y3,x4,y4,x5,y5,x6,y6,level,color1,
			color2);
	}
}



void plot_triangle(int x1, int y_one, int x2, int y2, int x3, int y3,int color1,
	int color2)
{
	int ytt,color,temp;
	float zt;

	if (y_one > y2)
		ytt = y_one;
	else
		ytt = y2;
	if (ytt < y3)
		ytt = y3;
	zt = (y_max+240)*(1-(float)(ytt+240)/(y_max+240)*
		(float)(ytt+240)/(y_max+240));
	temp = 32767/(y_max+241);
	temp = rand()/temp;
	if (temp <= zt)
		color = color1;
	else
		color = color2;
	if (ytt + 240 < (.35 * (y_max + 240)))
		color = color1;
	if (ytt+240 > (.92 * (y_max+240)))
		color = color2;
	fillTriangle(x1,y_one,x2,y2,x3,y3,PALETTE[color%16]+4);
}

void midpoint()
{
	float r,w;
	int sign1,sign2;

	r = 0.5 + random_no(1,0,.16666);
	w = random_no(1,.03,.07);
	xz = r*x - w*y;
	yz = r*y + w*x;
	xp = 0.05*y;
	yp = -0.05*x;
}

float random_no (unsigned int seed,float limit_start, float limit_end)
{
	float result;

	limit_end -= limit_start;
	limit_end = 16383.0/limit_end;
	result = (rand() - 16383)/limit_end;
	if (result >= 0)
		result += limit_start;
	else
		result -= limit_start;
	return(result);
}

void cactus (int x1, int y_one, int scale, int level, int color1, int color2)
{
	gen_quad(x1,y_one,x1,y_one+21*scale,x1+1.6*scale,y_one+22*scale,x1+
		1.6*scale,y_one,level,color1,color2);
	gen_quad(x1+1.4*scale,y_one,x1+1.4*scale,y_one+22*scale,x1+3*scale,
		y_one+21*scale,x1+3*scale,y_one,level,color1,color2);
	gen_quad(x1,y_one+9*scale,x1+7*scale,y_one+9*scale,x1+7*scale,y_one+12*scale,
		x1,y_one+12*scale,0,color1,color2);
	gen_quad(x1,y_one+9*scale,x1+6*scale,y_one+9*scale,x1+7*scale,y_one+12*scale,
		x1,y_one+12*scale,level,color1,color2);
	gen_quad(x1+7*scale,y_one+9*scale,x1+7*scale,y_one+16*scale,
		x1+8.5*scale,y_one+17*scale,x1+8.5*scale,y_one+9*scale,
		level,color1,color2);
	gen_quad(x1+8.4*scale,y_one+9*scale,x1+8.4*scale,y_one+16*scale,
		x1+10*scale,y_one+17*scale,x1+10*scale,y_one+10*scale,
		level,color1,color2);
	gen_quad(x1,y_one+7*scale,x1-6*scale,y_one+7*scale,x1-6*scale,y_one+10*scale,
		x1,y_one+10*scale,0,color1,color2);
	gen_quad(x1,y_one+7*scale,x1-6*scale,y_one+7*scale,x1-6*scale,y_one+10*scale,
		x1,y_one+10*scale,level,color1,color2);
	gen_quad(x1-7*scale,y_one+8*scale,x1-7*scale,y_one+12*scale,x1-5.4*scale,
		y_one+13*scale,x1-5.4*scale,y_one+7*scale,level,color1,color2);
	gen_quad(x1-5.6*scale,y_one+7*scale,x1-5.6*scale,y_one+13*scale,x1-4*scale,
		y_one+12*scale,x1-4*scale,y_one+7*scale,level,color1,color2);

}

void gen_quad (int x1, int y_one, int x2, int y2, int x3, int y3, int x4,
	int y4, int level, int color1, int color2)
{
	int x5,x6,x7,x8,x9,y5,y6,y7,y8,y9,ax,bx,cx,dx,ex,ay,by,cy,dy,ey;

	x = x2 - x1;
	y = y2 - y_one;
	midpoint();
	x5 = x1 + xz -xp;
	y5 = y_one + yz - yp;
	ax = -xp;
	ay = -yp;
	x = x4-x1;
	y = y4-y_one;
	midpoint();
	x7 = x1 + xz;
	y7 = y_one + yz;
	cx = xp;
	cy = yp;
	x = x4-x2;
	y = y4-y2;
	midpoint();
	x6 = x2 + xz;
	y6 = y2 + yz;
	bx = -xp;
	by = -yp;
	x = x3 - x2;
	y = y3 - y2;
	midpoint();
	x8 = x2 + xz -xp;
	y8 = y2 + yz - yp;
	dx = -xp;
	dy = -yp;
	x = x4-x3;
	y = y4-y3;
	midpoint();
	x9 = x3 + xz;
	y9 = y3 + yz;
	ex = xp;
	ey = yp;

	if (level == 0)
	{
		plot_triangle(x1,y_one,x5,y5,x7,y7,color1,color2);
		plot_triangle(x7,y7,x6,y6,x4,y4,color1,color2);
		plot_triangle(x5,y5,x6,y6,x7,y7,color1,color2);
		plot_triangle(x5,y5,x2,y2,x6,y6,color1,color2);
		plot_triangle(x2,y2,x8,y8,x9,y9,color1,color2);
		plot_triangle(x9,y9,x6,y6,x4,y4,color1,color2);
		plot_triangle(x6,y6,x8,y8,x9,y9,color1,color2);
		plot_triangle(x6,y6,x2,y2,x8,y8,color1,color2);
	}
	else
	{
		plot_triangle(x1,y_one,x5+ax,y5+ay,x7+cx,y7+cy,color1,color2);
		plot_triangle(x7+cx,y7+cy,x6+bx,y6+by,x4,y4,color1,color2);
		plot_triangle(x5+ax,y5+ay,x6+bx,y6+by,x7+cx,y7+cy,color1,
			color2);
		plot_triangle(x5+ax,y5+ay,x2,y2,x6+bx,y6+by,color1,color2);
		plot_triangle(x2,y2,x8+dx,y8+dy,x9+ex,y9+ey,color1,color2);
		plot_triangle(x9+ex,y9+ey,x6+bx,y6+by,x4,y4,color1,color2);
		plot_triangle(x6+bx,y6+by,x8+dx,y8+dy,x9+ex,y9+ey,color1,
			color2);
		plot_triangle(x6+bx,y6+by,x2,y2,x8+dx,y8+dy,color1,color2);
		node(x1,y_one,x2,y2,x4,y4,x5,y5,x6,y6,x7,y7,level,color1,
			color2);
		node(x2,y2,x3,y3,x4,y4,x8,y8,x9,y9,x6,y6,level,color1,
			color2);
	}
}

void fillTriangle (int x1, int y1, int x2, int y2, int x3, int y3,
	int color)
{
	if(W_r != 1)
	{
	#define sign(x) ((x) > 0 ? 1:  ((x) == 0 ? 0:  (-1)))

	int dx, dy, dxabs, dyabs, i, j, k, px, py, sdx, sdy, x, y,
		xpoint[4], ypoint[4], xa[350],xb[350],
		start,end;
	long int check;
	int x_coord[350], y_coord[350];

	for (i=0; i<350; i++)
	{
		xa[i] = 640;
		xb[i] = 0;
	}
	xpoint[0] = x1 + 320;
	ypoint[0] = 175 - ((y1*93L) >> 7);
	xpoint[1] = x2 + 320;
	ypoint[1] = 175 - ((y2*93L) >> 7);
	xpoint[2] = x3 + 320;
	ypoint[2] = 175 - ((y3*93L) >> 7);
	xpoint[3] = xpoint[0];
	ypoint[3] = ypoint[0];
	px = xpoint[0];
	py = ypoint[0];
	for (j=0; j<3; j++)
	{
		dx = xpoint[j+1] - xpoint[j];
		dy = ypoint[j+1] - ypoint[j];
		sdx = sign(dx);
		sdy = sign(dy);
		dxabs = abs(dx);
		dyabs = abs(dy);
		x = 0;
		y = 0;
		if (dxabs >= dyabs)
		{
			for (k=0; k<dxabs; k++)
			{
				y += dyabs;
				px += sdx;
				if (y>=dxabs)
				{
					y -= dxabs;
					py += sdy;
				}
				if ((py>=0) && (py<=349))
				{
					if (px < xa[py])
						xa[py] = px;
					if (px > xb[py])
						xb[py] = px;
				}
			}
		}
		else
		{
			for (k=0; k<dyabs; k++)
			{
				py += sdy;
				x += dxabs;
				if (x>=dyabs)
				{
					x -= dyabs;
					px += sdx;
				}
				if ((py>=0) && (py<=349))
				{
					if (px < xa[py])
						xa[py] = px;
					if (px > xb[py])
						xb[py] = px;
				}
			}
		}
	}
	if (ypoint[0] < ypoint[1])
	{
		start = ypoint[0];
		end = ypoint[1];
	}
	else
	{
		start = ypoint[1];
		end = ypoint[0];
	}
	for (i=0; i<350; i++)
	{
		if (xa[i] < 0)
			xa[i] = 0;
		if (xb[i] > 639)
			xb[i] = 639;
	}
	if (ypoint[2] < start)
		start = ypoint[2];
	if (ypoint[2] > end)
		end = ypoint[2];
	if (start < 0)
		start = 0;
	if (end > 349)
		end = 349;
	for (i=start; i<=end; i++)
	{
		if (W_r == 1) break;
		for (j=xa[i]; j<=xb[i]; j++)
			{
			P_WHATSON();
			if(W_r==1) 
				{
				MessageBeep(MB_ICONEXCLAMATION);
				break; /* Soft Method*/
				}
			P_PUNKT(j,i,PALETTE[color%16]+4);
			}
		}
  	 }

}
    
