/* sierp2.c zum C Objekt f�r GFA Basic modifiziert HT '97*/
/* Erzeugung des Sierpinski-Dreiecks mittels Bin�r-Arithmetik */
/* Algorithmen zu Fraktale und Chaostheorie
   urspr�nglich von D.Herrmann (C) Addison-Wesley 1994 */

#include <windows.h>
#include <gfa.h>
#include <stdio.h>
#include <conio.h>

GPROC P_PUNKT(int x, int y, int color);
GVBOOL B_r;
GVBOOL B_r3;
GPROC P_WHATSON();
GVWORD W_getmaxx; /* so oder als Variable in sierpinsky(int mx, int my)...*/
GVWORD W_getmaxy;


main(){}

void far pascal sierpinsky()
{
	int x,y;
	int mx,my;
	{
	mx=W_getmaxx;
	my=W_getmaxy;
	for (y=0; y<256; y++)
		{
		P_WHATSON();
		if (B_r||B_r3) break;
		for (x=0; x<=y; x++)
  		if ((x & (y-x))==0) P_PUNKT((mx/2)+1.5*(x-(y/2)),1.5*y/*+(my/4)*/,y%16);
		}
	}
return;
}



