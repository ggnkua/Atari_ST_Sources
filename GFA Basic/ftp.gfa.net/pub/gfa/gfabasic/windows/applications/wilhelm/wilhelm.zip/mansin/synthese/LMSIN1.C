/* mandsin.c zum C Objekt f�r GFA Basic umgestaltet HT '97*/
/* Mandelbrot-Menge der Funktion c+pi*sin(z) */
/* Algorithmen zu Fraktale und Chaostheorie
   nach D.Herrmann (C) Addison-Wesley 1994 */

#include <windows.h>
#include <gfa.h>
#include <stdio.h>
#include <math.h>
#include <conio.h>

/* die mathe - Funtionen exp, sin, cos, fabs non ansi mit f(loat) - Endung,
trotzdem noch lahm */

int mx,my;
int col[9] = {0,1,9,2,10,4,12,14,6};
GPROC P_PUNKT(HWND hm, HDC dc, int x, int y, int color);
GFUNCN P_WHATSON(HWND hm, HDC dc); /* RETVAL...*/
HWND hm;
HDC dc;


main(){}

void far pascal Sinus(HWND hm, HDC dc, int getmaxx, int getmaxy)
{
	/*double PI=3.14159265358979;*/
	float a,b,u,v,x,y,dist,ch,cs,sh,ss,x1,y1,xmax,ymax;
	int i,i1,i2,j,j1,j2,k,l,r;
	mx=getmaxx/2; my=getmaxy/2;
	xmax=PI; ymax=0.75*PI;
	for (i=0; i< mx; i++)
	{
		if (r ==1)
		{
			MessageBeep(0); /* 2. Debug BEEP*/
			break;
		}
   		i1 = mx+i; i2 = mx-i;
   		for (j=0; j< my; j++)
   		{
			r=P_WHATSON(hm,dc);
			if (r==1) 
			{
				MessageBeep(MB_ICONEXCLAMATION); /*1. TATAA*/
				break;
			}
   			j1 = my+j; j2 = my-j;
   			a =  xmax*i/mx; b = ymax*j/my;
   			x = PI/2.;  y = 0.0;
   			for (k=1; k<=64; k++)
     			{
     				if (sqrtf(y*y)>15.) { l = 1+k % 8; break; }
     				u = expf(y); v = 1./u;
     				ch = (u+v)/2.; sh = (u-v)/2.;
     				ss = sinf(x); cs = cosf(x);
     				x1 = a+PI*ss*ch; y1 = b+PI*cs*sh;
				dist =sqrtf((x-x1)*(x-x1))+sqrtf((y-y1)*(y-y1));
     				/*dist = fabsf(x-x1)+fabsf(y-y1);*/
     				if (dist<.0005) {l=0; break; }
     				x = x1; y = y1; l=0;
     			}
  			P_PUNKT(hm,dc,i1,j1,col[l]); P_PUNKT(hm,dc,i1,j2,col[l]);
  			P_PUNKT(hm,dc,i2,j1,col[l]); P_PUNKT(hm,dc,i2,j2,col[l]);
  		}
 	}
 }

