/* als C Objekt f�r GFA Basic HT '97*/
#include <windows.h>
#include <gfa.h>
#include <string.h>

#if _MSC_VER >= 700
#pragma warning (disable:4028)
#endif

#define  IDS_ERR_CLASS  20
#define  IDS_ERR_WINDOW 21
#define  IDC_COMBO      100
#define  IDC_STATIC     110
#define  IDC_LIST       120

char szarString[128];  /* Variable zum Laden der Resource-Texte */
char szarAppName[20];  /* Klassenname des Fensters              */
HANDLE hInst;

int nCwRegisterClasses(HANDLE);	     /* statt WORD */
long FAR PASCAL WndProc( HWND, unsigned, unsigned, LONG);

main(){/* es gibt nix f�r dos*/}

/* WinMain() wird zur far Proc */

int far PASCAL WinMain(HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow)
{
   MSG	 msg;
   HWND  hWnd;
   int	 nError;

   strcpy(szarAppName, "Combobx");
   hInst = hInstance;

   if (!hPrevInstance)
   {
       if ((nError=nCwRegisterClasses(hInstance)) ==-1)
    {
       /* Registrierung schlug fehl		  */
       LoadString(hInstance, IDS_ERR_CLASS,
		  szarString, sizeof(szarString));
       MessageBox(NULL,szarString, NULL,
			 MB_ICONEXCLAMATION);
       return nError;
    }
   }

   /* Hauptfenster erzeugen			  */
   hWnd = CreateWindow(szarAppName,
	 "List - Combo Box aus C in GFA Basic",
	 WS_OVERLAPPED | WS_SYSMENU |
	 WS_MINIMIZEBOX | WS_BORDER,
	 CW_USEDEFAULT, 0,
	 2*GetSystemMetrics(SM_CXSCREEN)/3,
	 GetSystemMetrics(SM_CYSCREEN)/2,
	 NULL, NULL, hInstance, NULL);

   if(hWnd == NULL)
   {
     LoadString(hInstance, IDS_ERR_WINDOW,
       szarString, sizeof(szarString));
     MessageBox(NULL, szarString, NULL,
	  MB_ICONEXCLAMATION);
     return IDS_ERR_WINDOW;
   }
   ShowWindow( hWnd, nCmdShow );
   UpdateWindow( hWnd );

   while (GetMessage(&msg, NULL, 0, 0))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }
   return (int)msg.wParam;
}

int nCwRegisterClasses(HANDLE hInstance)
{
   WNDCLASS wcClass;

   wcClass.hCursor = LoadCursor( NULL, IDC_ARROW );
   wcClass.hIcon = LoadIcon( NULL, IDI_APPLICATION);
   wcClass.lpszMenuName = (LPSTR)NULL;
   wcClass.lpszClassName = szarAppName;
   wcClass.hbrBackground =
		(HBRUSH)GetStockObject(GRAY_BRUSH);
   wcClass.hInstance = hInstance;
   wcClass.style = CS_VREDRAW | CS_HREDRAW;
   wcClass.lpfnWndProc = WndProc;
   wcClass.cbClsExtra = 0 ;
   wcClass.cbWndExtra = 0 ;

   if (!RegisterClass( &wcClass ) )
      return FALSE;
   return TRUE;
}


long FAR PASCAL WndProc(HWND hWnd, unsigned
	       message, unsigned wParam, LONG lParam )
{
  static HWND hWndStatic, hWndCombo, hWndList;
  RECT	rect;
  static char szPathSpec[150];
  BOOL bVerzeichnis;
  int i;

  switch (message)
  {
    case WM_CREATE:
      GetClientRect(hWnd, &rect);
      hWndStatic = CreateWindow("static", "",
	      WS_CHILD | WS_VISIBLE | WS_BORDER,
	      10, 10,
	      rect.right-50, 30,
	      hWnd, IDC_STATIC, hInst, NULL);
      hWndCombo = CreateWindow("combobox", NULL,
	      WS_CHILD | WS_VISIBLE | WS_VSCROLL | CBS_SIMPLE | CBS_SORT,
	      10, 50,
	      rect.right/2-50, rect.bottom-60,
	      hWnd, IDC_COMBO, hInst, NULL);
      SetWindowText(hWndStatic, "Angabe des aktuellen Verzeichnisses");
      SendMessage(hWndCombo, CB_RESETCONTENT, 0, 0L);
      SendMessage(hWndCombo, CB_DIR, (WORD)(0x0|0x10), (LONG)(LPSTR)"*.*");
      hWndList = CreateWindow("combobox", NULL,
	      WS_CHILD | WS_VISIBLE | CBS_DROPDOWN | CBS_SORT,
	      rect.right/2,50,
	      rect.right/2-50, rect.bottom-70,
	      hWnd, IDC_LIST, hInst, NULL);
      SendMessage(hWndList, CB_RESETCONTENT, 0, 0L);
      SendMessage(hWndList, CB_DIR, (WORD)(0x4000), (LONG)(LPSTR)"");
      break;

    case WM_COMMAND:
      switch(wParam)
      {
	case IDC_COMBO:
	  if ( HIWORD(lParam) == CBN_DBLCLK )
	  {
	    DlgDirSelectComboBox(hWnd, szPathSpec, IDC_COMBO);
	    bVerzeichnis = TRUE;
	    for (i=1; i<9;i++)
	    {
	      if (szPathSpec[i] == '\0')
		break;
	      if (szPathSpec[i] == '.')
	      {
		bVerzeichnis = FALSE;
		break;
	      }
	    }
	    if (szPathSpec[0] == '.')
	      bVerzeichnis = TRUE;

	    if (bVerzeichnis == TRUE)
	    {
	      strcat(szPathSpec, "*.*");
	      DlgDirListComboBox(hWnd, szPathSpec, IDC_COMBO, IDC_STATIC, 0x0 |0x10);
	    }
	  }
	  break;

	case IDC_LIST:
	  if ( HIWORD(lParam) == CBN_SELCHANGE )
	  {
	    DlgDirSelectComboBox(hWnd, szPathSpec, IDC_LIST);
	    strcat(szPathSpec, "*.*");
	    DlgDirListComboBox(hWnd, szPathSpec, IDC_COMBO, IDC_STATIC, 0x0 |0x10);
	    SetWindowText(hWndCombo, "");
	    bVerzeichnis = TRUE;
	  }
	  break;

	default:
	  return (DefWindowProc(hWnd, message,
			      wParam, lParam));
	  break;
	 }
      break;

    case WM_DESTROY:
      PostQuitMessage(0);
      break;

    default:
      return (DefWindowProc( hWnd, message, wParam,
					 lParam ));
      break;
  }
  return(0L);
}

