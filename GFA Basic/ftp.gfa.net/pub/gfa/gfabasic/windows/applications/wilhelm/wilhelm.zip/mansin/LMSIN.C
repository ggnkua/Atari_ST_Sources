/* mandsin.c zum C Objekt f�r GFA Basic umgestaltet HT '97*/
/* Mandelbrot-Menge der Funktion c+pi*sin(z) */
/* Algorithmen zu Fraktale und Chaostheorie
   nach D.Herrmann (C) Addison-Wesley 1994 */

#include <windows.h>
#include <gfa.h>
#include <stdio.h>
#include <math.h>
#include <conio.h>

/*const double PI=3.141592653;*/
int mx,my;
int col[9] = {0,1,9,2,10,4,12,14,6};
GPROC P_PUNKT(int x, int y, int color);
GPROC P_WHATSON();
GVWORD W_r;
HWND hm;
HDC dc;


main(){/* nix f�r dos*/}

void far pascal Sinus(HWND hm, HDC dc, int getmaxx, int getmaxy)
{
	double a,b,u,v,x,y,dist,ch,cs,sh,ss,x1,y1;
	double xmax=PI,ymax=0.75*PI;
	int i,i1,i2,j,j1,j2,k,l;
	mx=getmaxx/2; my=getmaxy/2;
	for (i=0; i< mx; i++)
	{
		if (W_r ==1)
		{
			MessageBeep(0); /* 2. Debug BEEP*/
			break;
		}
   		i1 = mx+i; i2 = mx-i;
   		for (j=0; j< my; j++)
   		{
			P_WHATSON();
			if (W_r==1) 
			{
				MessageBeep(MB_ICONEXCLAMATION); /*1. TATAA*/
				break;
			}
   			j1 = my+j; j2 = my-j;
   			a =  xmax*i/mx; b = ymax*j/my;
   			x = PI/2.;  y = 0;
   			for (k=1; k<=64; k++)
     			{
     				if (fabs(y)>15.) { l = 1+k % 8; break; }
     				u = exp(y); v = 1./u;
     				ch = (u+v)/2.; sh = (u-v)/2.;
     				ss = sin(x); cs = cos(x);
     				x1 = a+PI*ss*ch; y1 = b+PI*cs*sh;
				dist =sqrt((x-x1)*(x-x1))+sqrt((y-y1)*(y-y1));
     				/*dist = fabs(x-x1)+fabs(y-y1);*/
     				if (dist<.0005) {l=0; break; }
     				x = x1; y = y1; l=0;
     			}
  			P_PUNKT(i1,j1,col[l]); P_PUNKT(i1,j2,col[l]);
  			P_PUNKT(i2,j1,col[l]); P_PUNKT(i2,j2,col[l]);
  		}
 	}
 }

