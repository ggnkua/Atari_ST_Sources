/* sierp.c als C Objekt f�r GFA Basic HT '97*/
/* Erzeugung des Sierpinski-Dreiecks mittels Chaos-Spiel */
/* Algorithmen zu Fraktalen und Chaostheorie
   urspr�nglich von D.Herrmann (C) Addison-Wesley 1994 */

#include <windows.h>
#include <gfa.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>

GPROC P_PUNKT(int x, int y, int color);
GVBOOL B_r;
GVBOOL B_r3;
GPROC P_WHATSON();
GVWORD W_getmaxx; /* so oder als Variable in sierpinsky(int mx, int my)...*/
GVWORD W_getmaxy;

main(){}

void far pascal sierpinsky()
{
	long int i;
	int p,x,y,mx,my;
	time_t now;

	srand((unsigned) time(&now) % 4001);
	mx=W_getmaxx;
	my=W_getmaxy;
	x = y = 0;
	for (i=1L; i<= 120000L; i++)
	{
		P_WHATSON();
		if(B_r||B_r3) break;
		p = rand() % 3; /* Alle Abb. gleichwahrscheinlich */
		switch(p)
  		{
  		case 0: x /= 2; y = (y+my)/2; break;
  		case 1: x = (x+mx)/2; y /= 2; break;
  		case 2: x = (x+mx)/2; y = (y+my)/2; break;
  		}
	if (i>20) P_PUNKT(x,y,i%63+1);
	}

}



