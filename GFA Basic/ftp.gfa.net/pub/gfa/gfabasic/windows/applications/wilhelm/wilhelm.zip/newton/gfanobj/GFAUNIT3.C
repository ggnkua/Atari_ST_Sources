/* z^3-1=0   HT '95 als GFA Basic auch als OBJ (?) HT '97*/

/*#include <windows.h>*/ /* braucht es hier nicht */
#include <gfa.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int max_iterations =124;

int   color,i;
double  x,y,xsquare,xold,yold,ysquare,ytemp, temp1,temp2,denom,theta;

/*HWND hdlw;
HDC dc;*/

main() /* Symantec fordert _main Def. */
{
}

int far pascal newton(int hdlw, int dc, long col, long row, double xmin,
        double ymax, double deltax, double deltay)
{
	
     x=xmin+col*deltax;
     y=ymax-row*deltay;
     xsquare=0;
     ysquare=0;
     xold=42;
     yold=42;
     for (i=0; i< max_iterations; i++)
     {
           xsquare=x*x;
           ysquare=y*y;
           denom=3*((xsquare-ysquare)*(xsquare-ysquare)+4*xsquare*ysquare);
           if (denom == 0.0000000)
              denom=0.00000001;
           x=0.6666667*x+(xsquare-ysquare)/denom;
           y=0.6666667*y-(2*x*y/denom);
           if ((xold==x)&&(yold==y)) 
              break;
           xold=x;
           yold=y;

     }
     if (x>0)
     color = (i%13)+3;
	else
     {	
     if ((x<-.3) && (y>0))
	color = (i%11) + 4;
	else
	color = (i%8) + 7;
     }
     return (color);
}
