/* Komplettes Win C Programm als C Objekt f�r GFA Basic HT '97*/
/* compilieren mit sc -a2 -f -ms (-cod) -c -S -2 =4096 gfac.c */
/* Programmaufbau modifiziert nach Irene Bauder - Greetings to
Australia - koala mu� hier drau�en bleiben */

/* GFA Basic als ultimativer Schnittpunkt f�r fast alle Windows Belange -
konkurriert hier an Handlichkeit mit dem WinIo System von A.Schulman...
wer kein C f�r Windows besitzt, aber einen C Compiler, der die Windows.h 
verdauen kann, mu� nicht l�nger auf Windows C Applikationen verzichten !*/

#include <windows.h>
#include <gfa.h>
#include <math.h>

#if _MSC_VER >= 700
#pragma warning (disable:4028)
#endif

BOOL GfaCInit ( HANDLE );
long FAR PASCAL GfaCWndProc( HWND, unsigned, unsigned, LONG);
main(){/* wir geben nix f�r dos*/}/* f�r die sds.lib, sie ist schlie�lich eine Dos LIB ! */

int far PASCAL WinMain( hInstance, hPrevInstance, lpszCmdLine, cmdShow )
HANDLE  hInstance, hPrevInstance;
LPSTR   lpszCmdLine;
int             cmdShow;
{
	MSG             msg;
	HWND    hWnd;

	if (!hPrevInstance) 
	{
		if (!GfaCInit( hInstance ))
			return FALSE;
	}

	hWnd = CreateWindow("GfaC", "GFA Basic meets Windows C",
		WS_OVERLAPPEDWINDOW,CW_USEDEFAULT, 0, CW_USEDEFAULT, 0,
		NULL, NULL, hInstance, NULL);

	while  (!SetTimer(hWnd, 1, 50, NULL))
		if (IDCANCEL == MessageBox(hWnd, "Es sind  zuviele Timer gestartet",
				"Timer", MB_RETRYCANCEL))
			return FALSE;

	ShowWindow( hWnd, cmdShow );
	UpdateWindow( hWnd );

	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return (int)msg.wParam;
}

BOOL GfaCInit( hInstance )
HANDLE hInstance;
{
	WNDCLASS        wcGfaCClass;

	wcGfaCClass.hCursor             =       LoadCursor( NULL, IDC_ARROW );
	wcGfaCClass.hIcon                       =LoadIcon( NULL, IDI_APPLICATION);
	wcGfaCClass.lpszMenuName        =       NULL;
	wcGfaCClass.lpszClassName       =       "GfaC";
	wcGfaCClass.hbrBackground       =       GetStockObject( BLACK_BRUSH );
	wcGfaCClass.hInstance           =       hInstance;
	wcGfaCClass.style                       =       CS_HREDRAW | CS_VREDRAW;
	wcGfaCClass.lpfnWndProc         =       GfaCWndProc;
	wcGfaCClass.cbClsExtra          =       0 ;
	wcGfaCClass.cbWndExtra          =       0 ;

	if (!RegisterClass( &wcGfaCClass ) )
		return FALSE;

	return TRUE;
}

long FAR PASCAL GfaCWndProc( hWnd, message, wParam, lParam )
HWND    hWnd;
unsigned        message;
unsigned    wParam;
LONG            lParam;
{
	HANDLE  hInst;
	HDC             hDC, hMem;
	static HBITMAP  hBit1,hBit2, hBit3,hBit4, hOld, hOld1, hOld2,hOld3;
	static BITMAP   bm,bm1,bm2,bm3;
	static int      xPos, xPos1, xPos2, xPos3, y1Pos, y2Pos, y3Pos,y4Pos, i;
	static int      xClient, yClient;
	static double   y, yy, x;

	switch (message)
	{
		case WM_CREATE:
			hInst = GetWindowWord( hWnd, GWW_HINSTANCE);
			hBit1 = LoadBitmap(hInst, "HT97");
			hBit2 = LoadBitmap(hInst, "COMP");
			hBit3 = LoadBitmap(hInst, "SMILE");
			hBit4 = LoadBitmap(hInst, "GFA");
			GetObject(hBit1, sizeof(BITMAP), (LPSTR)&bm);
			GetObject(hBit2, sizeof(BITMAP), (LPSTR)&bm1);
			GetObject(hBit3, sizeof(BITMAP), (LPSTR)&bm2);
			GetObject(hBit4, sizeof(BITMAP), (LPSTR)&bm3);
			break;

		case WM_SIZE:
			xClient = LOWORD(lParam);
			yClient = HIWORD(lParam);
			yClient = yClient - bm.bmHeight;
			y1Pos = yClient/2;
			y2Pos = yClient/2;
			y3Pos = yClient/2;
			y4Pos = yClient/2;
			x = xPos = 0; xPos1=80; xPos2=160; xPos3=240;
			y = 0.0;
			i = 0;
			break;

		case WM_TIMER:
			hDC = GetDC(hWnd);
			hMem = CreateCompatibleDC(hDC);

			PatBlt(hDC, xPos, y1Pos, bm.bmWidth, bm.bmHeight, BLACKNESS);
			PatBlt(hDC, xPos1, y2Pos, bm1.bmWidth, bm1.bmHeight, BLACKNESS);
			PatBlt(hDC, xPos2, y3Pos, bm2.bmWidth, bm2.bmHeight, BLACKNESS);
			PatBlt(hDC, xPos3, y4Pos, bm3.bmWidth, bm3.bmHeight, BLACKNESS);
			x = i * 3.14159/50;
			xPos = i * (xClient/200);
			xPos1 = xPos+80; xPos2 = xPos1+80; xPos3 =xPos2+80;
			i++;
			if (xPos1 >xClient) xPos1=80;
			if (xPos2 >xClient) xPos2=160;
			if (xPos3 >xClient) xPos3=240;
			if (xPos > xClient)
				i = 0;
			
			y = sin(x);
			yy =cos(x);

			hOld = SelectObject(hMem, hBit1);
			y1Pos = (int)(-y * ((double)yClient)/2 + ((double)yClient)/2);
			BitBlt(hDC, xPos, y1Pos, bm.bmWidth, bm.bmHeight, hMem, 0,0, SRCCOPY);
			
			hOld1 = SelectObject(hMem, hBit2);
			y2Pos = (int)(y * ((double)yClient)/2 + ((double)yClient)/2);
			BitBlt(hDC, xPos1, y2Pos, bm1.bmWidth, bm1.bmHeight, hMem, 0,0, SRCCOPY);
			
			hOld2 = SelectObject(hMem, hBit3);
			y3Pos = (int)(yy * ((double)yClient)/2 + ((double)yClient)/2);
			BitBlt(hDC, xPos2, y3Pos, bm2.bmWidth, bm2.bmHeight, hMem, 0,0, SRCCOPY);
			
			hOld3 = SelectObject(hMem, hBit4);
			y4Pos = (int)(-yy * ((double)yClient)/2 + ((double)yClient)/2);
			BitBlt(hDC, xPos3, y4Pos, bm3.bmWidth, bm3.bmHeight, hMem, 0,0, SRCCOPY);
			
			SelectObject(hMem, hOld);
			SelectObject(hMem, hOld1);
			SelectObject(hMem, hOld2);
			SelectObject(hMem, hOld3);
			DeleteDC(hMem);
			ReleaseDC(hWnd, hDC);

			break;

		case WM_DESTROY:
			KillTimer( hWnd, 1);
			DeleteObject(hBit1);
			DeleteObject(hBit2);
			DeleteObject(hBit3);
			DeleteObject(hBit4);
			PostQuitMessage(0);
			break;

		default:
			return (DefWindowProc( hWnd, message, wParam, lParam ));
			break;
	}
	return(0L);
}
