This folder includes GB32 sample files showing how to use
the ActiveX version of PDFlib.

PDFlib is a Portable C library for dynamically generating PDF
("Adobe Acrobat") files, with support for many other programming
languages.

If you want to run these samples first download the binary
PDFlib ActiveX package from http://www.pdflib.com, run the
setup and then load the samples and execute them.

(see readme (PDFlib).txt for further information)