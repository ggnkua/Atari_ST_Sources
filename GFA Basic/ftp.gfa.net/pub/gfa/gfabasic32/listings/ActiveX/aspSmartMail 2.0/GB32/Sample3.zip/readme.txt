This folder includes GB32 sample files showing how to use
the aspSmartMail 2.0 ActiveX from ADVANTYS.

aspSmartMail is a free, fully-featured ASP component;
it provides you with all the Mail features you could possibly wish for : 

Add Electronic Mail to your Web applications. 
+ SMTP (sending) Messages 
+ Plain text or HTML for the message's body
+ Priority settings 
+ Carbon Copy (CC) 
+ Blind Carbon Copy (BCC) 
+ Reply-To, ConfirmReading and ReturnReceipt
+ US ASCII
+ ContentType headers
+ Custom headers
+ Multiple File Attachments
+ MIME with BASE64 


If you want to run these samples first download the aspSmartMail
package from http://www.aspSmart.com, unpack it and copy the
aspSmartMail.dll in a shared folder (e.g. system folder). Then
register it on your computer by using RegSvr32 (located in Windows
or Windows/System folder).

1. Copy aspSmartMail.dll into to a folder on your computer (e.g. c:\mydir).
2. Save it using the commands :
        REGSVR32.EXE c:\mydir\aspSmartMail.dll (In DOS or using Start/Run...)


That's all. There is no need to run a webserver for using this component.
After registering aspSmartMail.dll just load the GB32 sample files and
execute them (requires a connection to the internet to succeed).
