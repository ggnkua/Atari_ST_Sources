This folder includes GB32 sample files showing how to use
the SndMail 1.9 Dll from Davide Libenzi.

SndMail is a Windows SMTP mail delivery agent distributed as a
Dll and released under the Gnu Public License.

If you want to run these samples first download the package
from http://www.xmailserver.org/davide.html,
extract SndMail.dll and copy it into the sample folder.
Then load the samples and execute them.


