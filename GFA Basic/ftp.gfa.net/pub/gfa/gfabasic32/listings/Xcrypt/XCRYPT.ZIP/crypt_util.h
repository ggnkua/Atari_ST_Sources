/*
 *  Prototypes
 */
#ifdef __STDC__
#ifdef DEBUG
void           pr_bits              (ufc_long *, int);
static void    set_bits             (ufc_long, ufc_long *);
#endif	/* DEBUG */
STATIC void    clearmem             (char *, int);
void init_des                       (void);
#ifdef _UFC_32_
STATIC void    shuffle_sb           (long32 *, ufc_long);
#endif	/* _UFC_32_ */
#ifdef _UFC_64_
STATIC void    shuffle_sb           (long64 *, ufc_long);
#endif	/* _UFC_64_ */
STATIC void    setup_salt           (char *);
STATIC void    ufc_mk_keytab        (char *);
ufc_long      *ufc_dofinalperm      (ufc_long, ufc_long, ufc_long,
                                     ufc_long);
STATIC char   *output_conversion    (ufc_long, ufc_long, char *);
char          *crypt                (char *, char *);
char          *fcrypt               (char *, char *);
void           encrypt              (char *, int);
void           setkey               (char *);
#else		/* ! __STDC__ */
#ifdef DEBUG
void           pr_bits              ();
static void    set_bits             ();
#endif	/* DEBUG */
STATIC void    clearmem             ();
void init_des                       ();
#ifdef _UFC_32_
STATIC  void    shuffle_sb           ();
#endif	/* _UFC_32_ */
#ifdef _UFC_64_
STATIC void    shuffle_sb           ();
#endif	/* _UFC_64_ */
STATIC void    setup_salt           ();
STATIC void    ufc_mk_keytab        ();
ufc_long      *ufc_dofinalperm      ();
STATIC char   *output_conversion    ();
char          *crypt                ();
char          *fcrypt               ();
void           encrypt              ();
void           setkey               ();
#endif	/* __STDC__ */
