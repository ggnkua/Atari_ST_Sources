#include <windows.h>
// #include <ole2.h>
#include "crypt_util.h"


#define CCONV _stdcall

BSTR CCONV xcrypt (BSTR *bstrClearPwd)
{
	BSTR bstrEncPwd;
	bstrEncPwd = SysAllocStringLen(NULL, 13);
	crypt((LPSTR)bstrClearPwd, "as");
	return bstrEncPwd;
}

