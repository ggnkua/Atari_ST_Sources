/* Resource Datei Indizes f�r XA_XTOBJ */

#define EXT_AESOBJ       0   /* Formular/Dialog */
#define XOBJ_R_DSEL      1   /* USERDEF in Baum EXT_AESOBJ */
#define XOBJ_R_SEL       2   /* USERDEF in Baum EXT_AESOBJ */
#define XOBJ_B_DSEL      3   /* USERDEF in Baum EXT_AESOBJ */
#define XOBJ_B_SEL       4   /* USERDEF in Baum EXT_AESOBJ */
#define EXTOBJ_NAME      5   /* STRING in Baum EXT_AESOBJ */
