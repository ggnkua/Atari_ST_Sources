/* Resource Datei Indizes f�r NINE-OZK */

#define EXT_AESOBJ       0   /* Formular/Dialog */
#define EXTOBJ_NAME      5   /* STRING in Baum EXT_AESOBJ */
