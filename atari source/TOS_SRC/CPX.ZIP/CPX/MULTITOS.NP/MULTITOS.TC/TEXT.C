
These are text strings used in a CPX that will rename multitos to PRX or PRG.
Please translate these as soon as possible.  If there are any questions,
please contact us as soon as possible.




MultiTOS Config		-> Title in a CPX header

MultiTOS Configuration  -> Title in the CPX

Memory Protection

Enable			-> If the word is too long, how about 'ON'

Disable			-> and 'OFF'?


char nomint[] = "[1][ | MultiTOS is NOT | Available. ][ OK ]";


char NoOn[] = "[1][ | Unable to enable MultiTOS. | Please check your files. ][ OK ]";


char NoWrite[] = "[1][ The disk is write | protected. Unable to enable | MultiTOS ][ OK ]";


char NoWrite2[] = "[1][ The disk is write | protected. Unable to disable | MultiTOS ][ OK ]";


char NoOff[] = "[1][ | Unable to disable MultiTOS. | Please check your files. ][ OK ]";


char RebootText[] = "[1][ Please reboot the system | for this change to take | effect. ][ OK ]";


OK			-> True, we already know these...

Cancel
