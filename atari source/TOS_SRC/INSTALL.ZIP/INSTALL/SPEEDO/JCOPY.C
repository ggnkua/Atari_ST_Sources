void
filecpy( char *src, char *dest )
{
	struct FILEINFO *olddta;
	struct FILEINFO newdta;


	olddta = Fgetdta();
	Fsetdta( &newdta ); 

	if( Fsfirst( src, 0 ) 


	fsize = info.size;
redo_mem:
	fbuf = Malloc( fsize * 2L );
	if( !fbuffer )
	{
		
