#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <dos.h>
#include <math.h>

void main(void)
{	int a = - 1;
    	int b = abs(a);

}
