To write the install disk in this directory to a real Atari floppy:
(720K DSDD 3.5" floppy)

$ dd of=/dev/fd0u720 if=Cumana_OSK_TOS_Install.img
