OS-9/68000 on the Atari ST
---
OS-9/68000 v2.3 was ported to the Atari ST series of computers by
Recc-o-ware around 1989/90 for Cumana. It was only distributed in
Europe (to my knowledge), so it's a very rare piece of software for
North Americans. Took me about 10 years to track it down :-)!

NOTES
-----
Cumana OS-9 was distributed on double-density 80/18/256b/2 disks
(that's 80 tracks, 18 sectors/track, 256 byte sectors, double-sided, with
track=0, sect=0, also known as '/d0' format); or 80/16/256b/2 with track=0,
sect=1, also known as 'u0' format).

Note that since OS-9's RBF format can number sectors on a track from 0,
as opposed to 1 (TOS/GEM and MS-DOS), this makes for some difficulties
reading '/d0' format disks in DOS/Windows and, surprisingly, Linux. The fd
drivers
seem to dislike sectors starting at 0, so one can't just use the standard
trick in Linux of 'dd if=/dev/fd0 of=img.dat'; one must use the low-level
'setfdprm' utility to read single sectors at a time. Bob van der Poel made
some good utilities which allow use of setfdprm to read and write
OS-9 disks (6809 and 68000) with ease. See the 'DiskUtils' directory for
more info.

-rlm 2006-03-30

