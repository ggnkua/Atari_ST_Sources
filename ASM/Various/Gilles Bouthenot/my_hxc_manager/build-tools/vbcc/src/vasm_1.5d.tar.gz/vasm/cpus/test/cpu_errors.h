"illegal operand",ERROR,
  "illegal qualifier <%s>",ERROR,
  "illegal relocation",ERROR,
  "data size not supported",ERROR,

