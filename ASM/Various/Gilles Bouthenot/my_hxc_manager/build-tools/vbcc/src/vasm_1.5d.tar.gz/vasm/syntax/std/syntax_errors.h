  "mnemonic expected",ERROR,
  "invalid extension",ERROR,
  "no space before operands",WARNING,
  "too many closing parentheses",WARNING,
  "missing closing parentheses",WARNING,
  "missing operand",ERROR,                        /* 5 */
  "scratch at end of line",WARNING,
  "\" expected",WARNING,
  "invalid data operand",ERROR,
  ", expected",WARNING,
  "identifier expected",ERROR,                    /* 10 */
  "",WARNING,
  "expression must be constant",ERROR,
  "unexpected endm without macro",ERROR,
  "endif without if",ERROR,
  "if without endif",ERROR,                       /* 15 */
  "maximum if-nesting depth exceeded (%d levels)",FATAL|ERROR,
  "else without if",ERROR,
  "syntax error",ERROR,
  "unexpected endr without rept",ERROR,
  "symbol <%s> already defined with %s scope",WARNING, /* 20 */
  ".fail %lld encountered",WARNING,
  ".fail %lld encountered",ERROR,
