  "syntax error",ERROR,
  "invalid extension",ERROR,
  "no space before operands",WARNING,
  "too many closing parentheses",WARNING,
  "missing closing parentheses",WARNING,
  "missing operand",ERROR,                                           /* 5 */
  "garbage at end of line",WARNING,
  "%c expected",WARNING,
  "invalid data operand",ERROR,
  ", expected",WARNING,
  "identifier expected",ERROR,                                       /* 10 */
  "",WARNING,
  "expression must be a constant",ERROR,
  "repeatedly defined symbol",ERROR,
  "endif without if",ERROR,
  "if without endif",ERROR,                                          /* 15 */
  "maximum if-nesting depth exceeded (%d levels)",FATAL|ERROR,
  "else without if",ERROR,
  "unexpected endr without macro",ERROR,
  "unexpected endr without rept",ERROR,
  "symbol <%s> already defined with %s scope",WARNING,               /* 20 */
  "assertion \"%s\" failed: %s",ERROR,
