  "mnemonic expected",ERROR,
  "invalid extension",ERROR,
  "no space before operands",WARNING,
  "too many closing parentheses",WARNING,
  "missing closing parentheses",WARNING,
  "missing operand",ERROR,                                           /* 5 */
  "garbage at end of line",WARNING,
  "syntax error",ERROR,
  "invalid data operand",ERROR,
  ", expected",WARNING,
  "identifier expected",ERROR,                                       /* 10 */
  "directive has no effect",WARNING,
  "expression must be a constant",ERROR,
  "illegal section type",ERROR,
  "repeatedly defined symbol",ERROR,
  "illegal memory type",ERROR,                                       /* 15 */
  "unexpected %s without %s",ERROR,
  "",ERROR,
  "",ERROR,
  "maximum if-nesting depth exceeded (%d levels)",FATAL|ERROR,
  "",ERROR,                                                          /* 20 */
  "missing %c",WARNING,
