# Monochrome-Bitmap-Converter
A free tool for converting monochromatic bitmaps to data arrays for LCD displays. Primary use case was designed for the atari ST. 

#### Usage
```
chmod ugo+rwx make.sh
sh make.sh 
./bit_rip -n 2 -f badguy.bmp -a badguy -s badguy.c
```
> Michael S. Walker <sigmatau@heapsmash.com>
